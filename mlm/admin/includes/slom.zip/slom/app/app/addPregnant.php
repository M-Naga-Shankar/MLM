<?php 
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';

       $sl_id=mysqli_query($conn,"select * from pregnant");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
              $sl_no=$j['id'];
           }
           $rq_no=$sl_no+1;
        
if($conn==true){
    echo "ok done";
}
else{
    echo "no";
}
if(!empty($_POST))
{
	$date=date('y/m/d');
    date_default_timezone_set("Asia/Kolkata");
 
                  date_default_timezone_get();
                $time=date('h:i:s'); 
                $name=$_POST['name'];
  
	$dob=$_POST['dob'];
    
	$month=$_POST['month'];
    $husband=$_POST['husband'];
	$number=$_POST['number'];
    $ddate=$_POST['ddate'];
    $pincode=$_POST['address'];
    $ref=$_SESSION['userid'];
	$subrefer=$_SESSION['ref'];
	echo $ddate;

   if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
     // Replace with your actual unique identifier
    
        // Specify the destination directory to save the uploaded file
        $targetDirectory = 'pregnant/';
    
        // Check if the directory exists, create it if not
        if (!file_exists($targetDirectory)) {
            mkdir($targetDirectory, 0755, true);
            chmod($targetDirectory, 0755);
        }
    
        // Generate the target file path
        $targetFile = $targetDirectory . basename($rq_no . ".png");
    
        // Print the target file path for debugging
        echo "Target File: " . $targetFile . "<br>";
    
        // Move the uploaded file to the destination directory
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
            echo "The photo has been uploaded successfully.";
        } else {
            echo "Sorry, there was an error uploading the photo.";
        }
    } else {
        echo "No photo was uploaded or an error occurred during the upload.";
      
        // Display specific error information for debugging
        echo "<br>File upload error: " . $_FILES['photo']['error'];
    }
    
    
    $photo=$rq_no.".png";
 
	$sql=mysqli_query($conn,"INSERT INTO `pregnant`(`time`, `date`, `refer`, `sub_refer`, `name`, `dob`,`husband_name`, `delivery_date`,  `village`, `phone`, `photo`) VALUES ('$time','$date','$ref','$subrefer','$name','$dob','$husband','$ddate','$pincode','$number','$photo')");

   	

	if($sql==true)
	{
    
		
    $uid=$userId;
    echo "ok done";
     header("Location:newapp.php?status=1");
   
	}
	else
	{
		$status=2;
		 echo "no";
	
	      header("Location:newapp.php?status=2");
	}
}

?>