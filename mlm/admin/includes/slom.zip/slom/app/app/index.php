<?php $active=1; ?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:47:48 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
   <?php include 'includes/appHeader.php'; ?>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">


            <!-- Card Overlay Carousel -->
          
            <!-- * Card Overlay Carousel -->

            <!-- Post Carousel -->
            
            <!-- * Post Carousel -->



            <!-- * post list 

            <div class="divider mt-2 mb-4"></div>-->
            <div class="sectionTitle mb-2 mt-5">
                <div class="text-muted">Our</div>
                <div class="title">
                    <h1>Services</h1>
                    <a href="#">View All</a>
                </div>
            </div>
            <!-- Iconed Box -->
            <div class="row">
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap " style=" background: #00FF00;">
                            <i class=""><iconify-icon icon="ph:student-fill" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">Students</h4>
                        Use the lastest easy to use components.
                    </div>
                </div>
                <!-- item -->
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-danger">
                            <i class=""><iconify-icon icon="healthicons:pregnant-outline" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">Pregnant Ladies</h4>
                        We designed Bitter UX based, simple and clean.
                    </div>
                </div>
                <!-- item -->
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-success">
                            <i class=""><iconify-icon icon="ion:woman-outline" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">Widow</h4>
                        With Bitter you can easily build and edit the theme.
                    </div>
                </div>
                <!-- item -->
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-info">
                            <i class=""><iconify-icon icon="healthicons:old-woman-outline" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">Old Age Women</h4>
                        Does not require long installation.
                    </div>
                </div>
                <!-- item -->
            </div>
            <!-- * Iconed Boxes -->


            <!-- listview -->
           
            <!-- * listview -->

        </div>

        <!-- app Footer -->
       
        <!-- * app Footer -->


    </div>
    <!-- * appCapsule -->




    <!-- App Bottom Menu -->
   <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->

    <!-- Sidebar Menu -->
   
        
    </div>
    <!-- * Sidebar Menu -->


    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:09 GMT -->
</html>