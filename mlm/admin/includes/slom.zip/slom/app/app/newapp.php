<?php $active=2; 
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';
?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:47:48 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
<style>
    

.modal {
  display: none;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal-content {
  background-color: #fff;
  padding: 20px;
  border-radius: 5px;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  
  width: 90%;
  max-height:550px;
  overflow:scroll;
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
  cursor: pointer;
}

.close:hover {
  color: #000;
}

.modal-button {
  padding: 10px 20px;
  background-color: #007BFF;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.modal-button:hover {
  background-color: #0056b3;
}

    </style>
    <script>
        function openModal(a) {
  document.getElementById("modal"+a).style.display = "block";
}

function closeModal(a) {
  document.getElementById("modal"+a).style.display = "none";
}

// Close the modal if the user clicks outside the modal content
window.onclick = function(event) {
  const modal = document.getElementById("modal");
  if (event.target === modal) {
    closeModal();
  }
};

</script>

<script>
        document.getElementById('fileInput').addEventListener('change', validateFileSize);

        function validateFileSize() {
            var fileInput = document.getElementById('fileInput');
            var fileSizeError = document.getElementById('fileSizeError');
            var maxFileSizeInBytes = 1024 * 1024; // 1 MB, set your desired maximum file size

            // Check if a file is selected
            if (fileInput.files.length > 0) {
                var fileSize = fileInput.files[0].size;

                if (fileSize > maxFileSizeInBytes) {
                    fileSizeError.textContent = 'File size should not exceed ' + (maxFileSizeInBytes / (1024 * 1024)) + ' MB.';
                    document.getElementById('myForm').addEventListener('submit', preventSubmission);
                } else {
                    fileSizeError.textContent = '';
                    document.getElementById('myForm').removeEventListener('submit', preventSubmission);
                }
            }
        }

        function preventSubmission(event) {
            event.preventDefault();
        }
    </script>
    <script>
    function validateDate() {
      var dobInput = document.getElementById('dob');
      var errorMessage = document.getElementById('error-message');

      // Check if a date is selected
      if (!dobInput.value) {
        errorMessage.textContent = 'Please enter your Date of Birth.';
        return;
      }

      // Get the entered date
      var dob = new Date(dobInput.value);

      // Get the current date
      var currentDate = new Date();

      // Calculate the minimum allowed date (50 years ago)
      var minDate = new Date();
      minDate.setFullYear(currentDate.getFullYear() - 50);

      // Compare the entered date with the minimum allowed date
      if (dob < minDate) {
        errorMessage.textContent = ''; // Clear previous error message
        // You can proceed with further actions here
      } else {
        errorMessage.textContent = 'You must be at least 50 years old.';
      }
    }
  </script>
      <script>
    function validateDate1() {
      var dobInput = document.getElementById('dob1');
      var errorMessage = document.getElementById('error-message1');

      // Check if a date is selected
      if (!dobInput.value) {
        errorMessage.textContent = 'Please enter your Date of Birth.';
        return;
      }

      // Get the entered date
      var dob = new Date(dobInput.value);

      // Get the current date
      var currentDate = new Date();

      // Calculate the minimum allowed date (50 years ago)
      var minDate = new Date();
      minDate.setFullYear(currentDate.getFullYear() - 10);

      // Compare the entered date with the minimum allowed date
      if (dob < minDate) {
        errorMessage.textContent = ''; // Clear previous error message
        // You can proceed with further actions here
      } else {
        errorMessage.textContent = 'You must be at least 10 years old.';
      }
    }
  </script>

</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
   <?php include 'includes/appHeader.php'; ?>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">


            <!-- Card Overlay Carousel -->
        
            <!-- * Card Overlay Carousel -->

           
 
            <?php if(!empty($_GET['status'])){
    $status=$_GET['status'];
    
    if($status==1){
        ?>  
       <br>
        <div class="alert alert-success" role="alert">
  Submited Successfully,<br>  Request Will Be Verified Soon
</div>
<?php 
    }
    
else{
        ?> 
        <br>
        <div class="alert alert-danger" role="alert">
  Error ! Incorrect Data Found
</div>
<?php 
    }
    
} ?>
           
            <!-- * post list -->
            <div class="sectionTitle mb-2 mt-4">
                <div class="text-muted">Create</div>
                <div class="title">
                    <h1>Application </h1>
                </div>
            </div>

            <!-- Iconed Box -->
            <div class="row">
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap " style=" background: #00FF00;" onclick="openModal(1)">
                            <i class=""><iconify-icon icon="ci:list-add" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title"> &nbsp;New Child &nbsp;Application</h4>
                        Click on the above icon to Create application.
                        
                    </div>
                </div>
                
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-warning" onclick="openModal(2)">
                            <i class=""><iconify-icon icon="ci:list-add" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">New Pregnant Application</h4>
                        Click on the above icon to Create application.
                        
                    </div>
                </div>
                
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-success" onclick="openModal(3)">
                            <i class=""><iconify-icon icon="ci:list-add" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">New Widow Application</h4>
                        Click on the above icon to Create application.
                        
                    </div>
                </div>
                
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-info" onclick="openModal(4)">
                            <i class=""><iconify-icon icon="ci:list-add" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">New Aged Woman Application</h4>
                        Click on the above icon to Create application.
                        
                    </div>
                </div>
                
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-danger" onclick="openModal(5)">
                            <i class=""><iconify-icon icon="ci:list-add" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">New Village Application</h4>
                        Click on the above icon to Create application.
                        
                    </div>
                </div>
                
                <!-- item -->
                <!-- item -->
             
                <!--Modal child 1-->
                <div class="modal" id="modal1">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Fill The Child Details</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(1)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>

<form action="addStudent.php" method="POST" id="myForm"  enctype="multipart/form-data">

<div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Name Of The Student</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Name" name="name" required>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Date Of Birth</label>
    <input type="date" id="dob1" class="form-control" placeholder="Enter Date Of Birth" name="dob" required onchange="validateDate1()">
    <p id="error-message1" style="color: red;"></p>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Class</label> 
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Class" name="class" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Parent Contact Number(optional)</label>
    <input type="number" max="9999999999" class="form-control" id="exampleInputEmail1" placeholder="Enter Parent contact Number" name="number">
  </div> 
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Location</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Location" name="address">
  </div> 
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Photo</label>
    <input type="file" id="fileInput"  class="form-control" name="photo" onchange="validateFileSize()" required>
        <p id="fileSizeError" style="color: red;"></p>

  </div>
  <div class="form-check">
    <input type="checkbox" checked class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">I Agree With T&C</label>
  </div>
  <br>
  <button type="submit" class="btn btn-success">Submit</button>
  <button type="reset" class="btn btn-danger">Cancel</button>
</form>
    </div>
  </div>
</div>
<!--end Modal-->
                <!--Modal pregnant 2-->
                <div class="modal" id="modal2">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Fill The Pregnant Details</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(2)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
<form action="addPregnant.php" method="POST" id="myForm"  enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Name Of The Pregnant</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Name" name="name">
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Date Of Birth</label>
    <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Enter Date Of Birth" name="dob">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Number Of Months</label>
    <input type="number" max="12" class="form-control" id="exampleInputEmail1" placeholder="Enter Present Month Ex 0-9" name="month">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Husband Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Husband Name" name="husband">
  </div>

  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Contact Number (optional)</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Conatact Number" name="number">
  </div> 
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Delivery Date</label>
    <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Enter Delivery Date" name="ddate">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Location</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Location" name="address">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Photo</label>
    <input type="file" id="fileInput"  class="form-control" name="photo" onchange="validateFileSize()" required>
        <p id="fileSizeError" style="color: red;"></p>

  </div>
  <div class="form-check">
    <input type="checkbox" checked class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">I Agree With T&C</label>
  </div>
  <br>
  <button type="submit" class="btn btn-success">Submit</button>
  <button type="reset" class="btn btn-danger">Cancel</button>
</form>
    </div>
  </div>
</div>
<!--end Modal-->
                <!--Modal widow 3-->
                <div class="modal" id="modal3">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Fill The widow Details</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(3)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
<form action="addWidow.php" method="POST" id="myForm"  enctype="multipart/form-data">

<div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Name" name="name" required>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Date Of Birth</label>
    <input type="date" class="form-control" id="exampleInputEmail1" placeholder="Enter Date Of Birth" name="dob" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Husband Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Husband Name" name="husband" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Contact Number</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Contact Number" name="number" >
  </div> 

  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Photo</label>
    <input type="file" id="fileInput"  class="form-control" name="photo" onchange="validateFileSize()" required>
        <p id="fileSizeError" style="color: red;"></p>

  </div>
  <div class="form-check">
    <input type="checkbox" checked class="form-check-input" id="exampleCheck1" required>
    <label class="form-check-label" for="exampleCheck1">I Agree With T&C</label>
  </div>
  <br>
  <button type="submit" class="btn btn-success">Submit</button>
  <button type="reset" class="btn btn-danger">Cancel</button>
</form>
    </div>
  </div>
</div>
<!--end Modal-->
                <!--Modal old age 1-->
                <div class="modal" id="modal4">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Fill The Aged Women Details</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(4)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
<form action="addAged.php" method="POST" id="myForm"  enctype="multipart/form-data">

<div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Name" name="name" required>
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Date Of Birth</label>
    <input type="date" id="dob" class="form-control" placeholder="Enter Date Of Birth" name="dob" required onchange="validateDate()">
    <p id="error-message" style="color: red;"></p>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Conatct Number</label>
    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Conatct Number" name="number" required>
  </div> 
  
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Photo</label>
    <input type="file" id="fileInput"  class="form-control" name="photo" onchange="validateFileSize()" required>
        <p id="fileSizeError" style="color: red;"></p>

  </div>
  <div class="form-check">
    <input type="checkbox" checked class="form-check-input" id="exampleCheck1" required>
    <label class="form-check-label" for="exampleCheck1">I Agree With T&C</label>
  </div>
  <br>
  <button type="submit" class="btn btn-success">Submit</button>
  <button type="reset" class="btn btn-danger">Cancel</button>
</form>
    </div>
  </div>
</div>
<!--end Modal-->
                <!--Modal child 1-->
                <div class="modal" id="modal5">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Fill The Village Details</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(5)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
<form action="addServey.php" method="POST" id="myForm"  enctype="multipart/form-data">

<div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Village Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" name="villageName" required>
</div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Village Population</label>
    <input type="number" class="form-control" id="exampleInputEmail1"  name="villagePopu" required>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1" style="color:black; font-weight:700; font-size:18px; ">Select Request</label>
    <select class="form-select" name="requesttype">
    <option value="Bore well">Bore well</option>
    <option value="Medical Camp">Medical Camp</option>
    <option value="Day Care Center">Day Care Center</option>
    <option value="Community Problem">Community Problem</option>
    <option value="Regular Problem">Regular Problem</option>
    <option value="Meterial Problem">Meterial Problem</option>

  </select>
  </div>
  <div class="form-check">
    <input type="checkbox" checked class="form-check-input" id="exampleCheck1" required>
    <label class="form-check-label" for="exampleCheck1">I Agree With T&C</label>
  </div>
  <br>
  <button type="submit" class="btn btn-success">Submit</button>
  <button type="reset" class="btn btn-danger">Cancel</button>
</form>
    </div>
  </div>
</div>
<!--end Modal-->                
<!-- item -->
                <!-- item -->
               
            <!-- * Iconed Boxes -->

         

        <!-- app Footer -->
       
        <!-- * app Footer -->


    </div>
    <!-- * appCapsule -->




    <!-- App Bottom Menu -->
   <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->

    <!-- Sidebar Menu -->
  

    <!-- * Sidebar Menu -->


    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:09 GMT -->
</html>