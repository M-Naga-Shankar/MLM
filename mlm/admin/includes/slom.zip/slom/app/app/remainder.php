<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/social-chat.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:25 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="#" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle">
           Remainder
            <div class="text-muted"></div>
        </div>
        <div class="right">
            <a href="#" class="icon">
                <i class="icon ion-ios-add"></i>
            </a>
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent pt-2">

            <div class="chatItem">
                <img src="assets/img/sample/avatar6.jpg" alt="avatar" class="avatar">
                <div class="content">
                    <div class="bubble">
                        Hey John, can we talk soon?
                    </div>
                    <footer>6 mins ago</footer>
                </div>
            </div>

            <div class="chatItem user">
                <div class="content">
                    <div class="bubble">
                        Sure Will.
                    </div>
                </div>
            </div>

            <div class="chatItem user">
                <div class="content">
                    <div class="bubble">
                        About what?
                    </div>
                    <footer>5 mins ago</footer>
                </div>
            </div>

            <div class="chatItem">
                <img src="assets/img/sample/avatar6.jpg" alt="avatar" class="avatar">
                <div class="content">
                    <div class="bubble">
                        <img src="assets/img/sample/photo3.jpg" alt="image" class="imageBlock xlarge rounded">
                    </div>
                    <footer>2 mins ago</footer>
                </div>
            </div>


            <div class="chatItem">
                <img src="assets/img/sample/avatar6.jpg" alt="avatar" class="avatar">
                <div class="content">
                    <div class="bubble">
                        Can you help me about photoshop?
                    </div>
                    <footer>1 mins ago</footer>
                </div>
            </div>

            <div class="chatItem user">
                <div class="content">
                    <div class="bubble">
                        Lorem ipsum dolor sit amet
                    </div>
                    <footer>now</footer>
                </div>
            </div>

            <div class="chatItem">
                <img src="assets/img/sample/avatar6.jpg" alt="avatar" class="avatar">
                <div class="content">
                    <div class="bubble">
                        Phasellus maximus dui a turpis porta, maximus lobortis magna pellentesque. Vivamus et justo eget
                        augue pellentesque faucibus sed lacinia dui.
                    </div>
                    <footer>1 mins ago</footer>
                </div>
            </div>

            <div class="chatItem user">
                <div class="content">
                    <div class="bubble">
                        Lorem ipsum dolor sit amet
                    </div>
                </div>
            </div>

            <div class="chatItem user">
                <div class="content">
                    <div class="bubble">
                        Nam auctor tellus a urna vestibulum molestie bibendum non neque.
                    </div>
                    <footer>now</footer>
                </div>
            </div>

            <div class="chatFooter">
                <div class="leftButton">
                    <button type="button" class="btn btn-secondary btn-icon">
                        <i class="icon ion-ios-camera"></i>
                    </button>
                </div>
                <form class="formArea">
                    <input type="text" class="form-control">
                    <button type="button" class="btn btn-primary btn-icon">
                        <i class="icon ion-ios-send"></i>
                    </button>
                </form>
            </div>

        </div>

    </div>
    <!-- appCapsule -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/social-chat.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:25 GMT -->
</html>