<?php $active=4;
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';
?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/search.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:25 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    
<script>
   
    $(document).ready(function () {
        $('#searchInput').on('input', function () {
            searchListItems();
        });
    });

    function searchListItems() {
        var input, filter, items, name, location, i;
        input = $('#searchInput').val().toUpperCase();
        items = $('.listItem');

        items.each(function () {
            name = $(this).find('#name strong').text().toUpperCase();
            location = $(this).find('#location').text().toUpperCase();
            status=$(this).find('#status').text().toUpperCase();

            if (name.indexOf(input) > -1 || location.indexOf(input) > -1|| status.indexOf(input)>-1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }
</script>
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="javascript:;" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle">Applications</div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">

            <div class="searchBlock mt-3">
                <form>
                    <span class="inputIcon">
                        <i class="icon ion-ios-search"></i>
                    </span>
                    <input type="text" class="form-control" id="searchInput" placeholder="Search...">
                </form>
            </div>


            <div class="sectionTitle mt-4 mb-0">
                <div class="text-muted">View</div>
                <div class="title">
                    <h1>Applications</h1>
                </div>
            </div>
   <!-- * post list -->

   <div class="divider mt-1 mb-2"></div>

   <!-- Iconed Box -->
   <div class="row">
       <!-- 
       <div class="col-6">
           <div class="iconedBox">
               <div class="iconWrap bg-success">
                   <i class=""><iconify-icon icon="icon-park-outline:list" style="font-size: 30px; color:black;"></iconify-icon></i>
               </div>
               <h4 class="title">Aproved Applications</h4>
               With Bitter you can easily build and edit the theme.
           </div>
       </div>
       <div class="col-6">
           <div class="iconedBox">
               <div class="iconWrap bg-warning">
                   <i class=""><iconify-icon icon="lucide:list-x" style="font-size: 30px; color:black;"></iconify-icon></i>
               </div>
               <h4 class="title">Pending Applications</h4>
               We designed Bitter UX based, simple and clean.
           </div>
       </div>
    -->
       <!-- item -->
    
       <!-- item -->
       <!-- item -->
    
       <!-- item -->
   </div>
   <!-- * Iconed Boxes -->
          

<!-- listview -->
<div class="listView detailed" id="lists">
<?php  
$userId=$_SESSION['userid'];
               $sl_id=mysqli_query($conn,"select * from application where refer='$userId'");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
               ?>
    <a href="userprofile.php?id=<?php echo "".$j['id']; ?>" class="listItem">
        <div class="image">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABJlBMVEX9/f0JkA88aKUAjAAAjQD//v8AjwD8/Pz///0AiQAAkQD//P8AiAA8aKT///v8/P3/+f8AgwA8aqM9ZqX///j++/n4/P0GkxA5Z6n6/vupvdTx9vkKjRD4/vgpXaD5+v8pX6N0k79IbaEtW6Y7aaE9Zq24yODs8Ph5u3hztXAAmQBltGeKwoSq162g06Pe8NwwmzTf5uzP3OWLn7xnh7FUd6yXrMTR3uwwX5qIncbCz93b6PKhstBce61fg7FskLZzksKxus5QdaSvwN3Y3+2UrdG6y9hddauQoczm8vPM1Oqfs8tUqVRUdLMzYa3Q68q64sHi8uRDn0SWyI+k07OdzaLI3rwllyuEyIjm7dg0ljVvtnax4rR0u3JTo1PY8tdgrWp8tn55rdXeAAAQD0lEQVR4nO2cC1fazLrHA2GSSYZkkFxHkhAVxRYRrxXx0ndb7T49sl+JvlZ3b7bf/0ucyQVEy01rCT1rfmtpLSpr/nmeeS5zkeMYDAaDwWAwGAwGg8FgMBgMBoPBYDAYDAaDwWAwGAwGg8FgMBgMBuNZYE4lkDNNoqc9kt8FhFBVVRj9A2Dao3lZIAgxq5tbW63W1tbpZkkMX4B/vkyRM0VDBeDD1vz2zqLv3WPvLrxZOS0DalOC8R+rVOQ4FVTfb/+70vR9W9OyWjZBKWZtKriyc75XAkBNe6DPA4fOWZrfUXxfU7JasZjVegKzmq1lFYW+7DUX91vmnzgry8jQzdZb37tXNQSt6RXfHAAOYzHtQT8FosPqYXbJHicv8lgl+7e30zL1P8eQWISg+qbiV4rKIyXx5/iLbPebWqVCHdY7amGIMU578ONREdLV0qG2/MA9Na2oKEVNs0O0rB2GHUVRHvyEd9wCqmikLWAsCLrwfbFZrCgPFXqe72V3dxYoO8eLTS+MP49+pLL0dhPMuhUxNsDBkbecjRNDqEFRNN/b/eu8tVmCOoygyb66tXJ2nPVsO3RWrSvR9g7N2U4dJjbIfLPnn3bFpvKyO/Onph5VMPf2Cf8LqnuHx03f7nNX6qqn6iyXraJafbu0XOnFFtv2d1ofgKES8vPPcrSeAdzm+W7zPuTSiar9i5vZoGpCcKr8XVS0yD8VWrVoh9WwYKEdxYAAIiLEEUKddmvBo9FHsyNP1RR/oazifnvPDHQKzt+bQ7P9k3euDsb/HoLc5rafvY9N/u6mroro94/4yYDt0BYRxWWvMl+acJhYdbnN/b7ywNa2gDh7rgrx/lISFKk1vLOSaojcJEFDRQVkQHh65GV7IWepFTbLM1XGYb284yVlSnHZPzl4qglM1XzX9Htm9FZomzxTZlTNHV8rxqOreGdlXXxipMCGDg+Ova7CZX8F4NlJjdiE3IJP+6M4HGZbtK19eiwk9DGd0V5ECR9URfOoo/6OwT4PFdIgk1jQP64S+MxQD7gVGo2TfNrc02cmY0B46NnJJGy+LavGsx8+VPcWuzHVrtAq9SWH+WxocbLiRa5Fi5jmGTZMDJ4bBaEJNxdtLXpYRWXXnAkrYk49bSYGtL1t8Gx1XaqLdmJG7S2chbyP1dKJnSSy5hsIxQnKmFEQvXrSXbLyD3/xzX4dMZyE234ksKh421H9+WtGJKa6uRgrVLTmKUy7YRSx2momid7eMV/mkcNTT4sW5hT7qGSkW9mInFhetGOF2qKpcy8i0VRb8Rod7U/OQMrrGkjdjyIfTfeVA9V8oVISwzM/siH1/APwq37/S4jGVlxoKdnmimqYL/bG5k4cT5Xlo3SrU2QeJ5Hd3gfwBR+1utldKVh6n96KuMghEE8Y+rFY0l/KR6P3Vt9FzqEVtV3RTG0qYpX8Ow4ymvdef9HkXCDcTrflf/eyb/0EsKi+X65E/YS3M2glZiDxXuK4rUOM4GayJKIVcWpNBuJ2s0XqocWKfwrR2GHookjlVTdbrdbeZhlAgLGqq4MTOuSA+j/xVKwsraQ1EaG6tZR05NuTjAEboDp/0vT9ZrNpK8fnWyZAxtDwhNUPSTi1T9Kq3QBcSPZY/M1JFKqlbS1cq7KXl5e1cIe0uN8qDQ+USD/z42Wfpb2UJBofvKhn0pa3wVgXJVD9X8WPGnilUilGVScNUNp+i05KVRwQhkVYaiZGXFC5VIINmPeVKFV4B2hsnoDGYVN7sBUTj77pF7dPARxYK4DteNtYa1Zfphx8Kng3Onvge3/BUfu3oR9iiP/yH26nJQqLmu1rR/MlMECCupnsgXgrqXT7sDQfc743ZC5hYhoQNMrE1Kv/ebybdi+S1teesr/nqgYhpG99DercUazQ/usl66XJgfHxH10fuupXQKDRXneRvtd/TGEgvvefwyqNrT1biUBE6vu/lbiiqKaTMDAWdV3HwxYOaWK/eJXvIARWoq2XkQqLRcVvvl0hKkiAZqm6uRenRMVLIyVShxLF0HcIZ/aIjnZBQug33DJs1CThAojumXcfY7RsxdaKA9VSb20Wz+bPz8/2F46PThQaYfyk9dT2U1gdxmAMdzU+l2nQVLBf6ZNR9P9+e7JUHGJJqsr3/Wi3/+E5jsXpx1IM66tdXiWEX9/erq1dXa2trbXn5JwTAFg6fjBWb78K8LmfHYxdoUlSs5XKw5cVxZ/+RDTRRo7n+Vz8KYbvR7AyTgBJdfHeI4uKZq9wYkEl75pjTxL1oxVpvoDTdlSVz4zEyQgdpFZ7S9i0hgn3pHSELxpAnfcqoyT9ZFr/DYBT7jBAQ3JGKrRyGzoiR/dZQlGW9ss6aGzkpSsAD71Rkn5SaL+dug1BJz/ahrJ8CdxTzw7LT4XmAsVWVnQC6nk5I8/dAnjWHFIBDGZx6ptt4HqMl2Yy/B0yj3yaH7Tw1ELlrKoXzCsq0LHkPLXi2dJT5mKzPO02GPyQR+uzMvwlp5L5nTA4Li6slKABgrZAv0M/HP4fAPaHRdRBeAdkyqUpqI21YUa6LiAIuFIpPCVLoHst935HlupAXWg+QeHWkNWA36ewPV6hxTdAgRjQMAAou/9syNb993LyR07csSeein4LTjfpA7gxViC1lFV3o5Unt3F1w8uZe4UWldhQzR170nDj/2vaCsnNeBtSBKG9erv2/SZHK7hHBpYzd1xpVxlTkfcUzk95YZgq7LPICCyZlwR5YFSSnf8C98gfVqP+pHDKLSLJTGRDJ2NZ1uBn4ViCFYDqyfJkCs+nrBCQjDyRDUfKlz8F8IAWAxM4KlU4ZS91b15AYUa+DNDB4iTRhnrpdGsaOg9/XSHtPuRLVz0t2uONSBVOVSDtfy8nizTjEL67YEuxxyZGf2Xa5zImyfgj4WUrbE7k/Gei7jXH3szwWlOvaV49TnBPFLi+JiVf/SDGijdOorc17dNDtPIe3R+OxHI2dLAWrgNQpDUA3veOjQ1TWCXT9tLx3dNI5BoGt3NWKFGeo73Uijdgzb+Ppjnt24rgo/RMbZHpaV1ac9Eq74TlgCVdA/jO00Zp3J1+B9zgn+WlliwkMZhKpK4e/y9fj9Y1hipUsgsAT3s3HwrPsqBw+cWJY5QstUXwdS5U6LzO13VwOLRdVJRmCifcwGVXYp8tu19aP1WjlkOhr0hf0Bc+CVJ8TTe+hq5gORbfAfqZF6lRovtt9KN3+UsJ28Op782A2266kGXaPNBPEblcLvzM8/yjmseS4xduGuCCj3sNJ3JUPnpZkDoAnHn+sh2uCUdHWLqfNfqSl8LWDEoW2xz569dal8+fV1dX1yJW2/wDP87VvoWmswSHSswL8a/yNKJ+jf7jvHY6Brf3ZmHn+Gh3d7HYJTZp82Tq+qjCIGn6ch+HbFxcXEYemBh6w3WpXztORrDuQEcSnES3a3yVQ/91ZKFR0KMVAYzLpT6q1WqplMLODAGXuWQ2DQwCIgBcXRC6U9PKrQMqMdQrUEftSN3n8x1wn3PRpOU/d9+oL/XFD2sagn6CoPUkIwrBoBGIInCRW8u/7s7WfCQxtGqOOmonHz0fx8rVCtRRY+Xu1FWMQkSBFHsgX0dk4FOmL4OOxUeOSsvsWGJo1MhR44jqZPivIlqlX9O48ziaiDjefgUFM419fAAv5dj/PsGhdb9ZCNq5xFHlOSoxXlLkqaN+SSJqRnqlc6/yvFwLCg9/GZlulxc6ffxEQD0pTec6Q1cYDJWAuiQk+YJfB0H0WKxcKFGKHVWWagV3vfMBIPTgQQHQlmSadiQpH4w/zvJbCBLrCLWhKwwYIxcFG7KTOPQ6Ci75cH2Kt6JwE6V7vu2WC0Al5IEMU2wkj0b+AVI6nQhqsZ9Z+buRIwCY1p+RRiGcixtC2PvySUQN65x6gfxcdIq9jQPpLrWDbY04mlp8e/QQCOhkogQYO+qnyHTRXJzLCxbv0KD70+/Awl0s0Mp8SkugSCBNiVYY8uc6ZnnET2II3O987NP8eiHYCPMiDbINcHd9KW90EPf4VgXCuOshGf5LWidoESl0oqLSseRP+pijyqpbt6LAkpurg/9uCHK44n+tmhwwyIBLIyamGdNJqqHU7uhjFcN2JNHKyFdj7kWIGDXakVPLuTpofL6R+Pw31zAMYg56Nqbh3ryOFeY7408+/jbo/MrHQTKsp9WRe5iEIHgt56Icf1cAbuPjhUuHjoE46FQeQWtxpUAbynTvkqJuvOMv1YI4+lkTEQQ1SaadrylG9eaIHFfodBdJwlNVLzzop4BxkHSJVn4NotE9nEqQCO9Wv9264cIgLo+4swWCm6SFlGtg0PHaqYFNcJucyXD4TmF05SyGR/BD24079E5UUItzvZORGzjdW+tlRCvNxJ3o9HqZNy2g23z8pnLuCqV7jxRjgi6SGeO83hjYRj0dUE/iV0Zou4XUb3RjcMUnq078N/fXT70QAr7IvSWgRqphJqHgfusV1m00qrSZCII63SVVR6infkuWIhZQw0mmoiO3J/lrJiMJ13ASH+W/zoIFQ8CF0D2KwLcDZJrPvrtrIlC/d9F22neAe6hgvbeJIVwGAD17ZGWwznctKN+4s2JCziDgKt5GCh010wHomZdJAV7t7WgJfCPd+7EPAWBN6q6M5vhrjMSnmtEkKgHBZe9IpyBfzNZfjMRwtSeRNsTBk5c4XVSgbbLcL3D8fb9pImJ3da63F8PL9adKVFHwPS8IyVvk5AtM+6rfM9bnEjqq1dt94i8bdDYSNIGvEhO5BOD1vm2OnHWX9jX8QSAaUe8HKfCvAjCmFO+CAepsSPdbVbmN8NTmbx7uM6C5rOP0JpJDNX5twMhZRxuS/kiHRph7gVLbRYY7Yy6aABqfJMvpjTUnffvoFkzOEAd0/7TrEwmh7VRwbfVs7zj0l9ZS2omZBL1A4829pzqWkHNu71zaEQ7Ma4DKq7el3L35nNf8zUc0M4l+AK4IOv1Ha6lBJeHm1T8BSS6khQ0XjvfMIGlctS0aPvscVM7XAjzLfxkyBAWv5h5ucOdyknTz/arTaLhcdBXfDRqd+o+2zD/cJXYs3gmzzKwUo0NQSRk02r1dw55xBF4QpDwvv7ascMc/PDf8+OSfzF+5YLa2EAcBw7BCOp8koe+MhpVxolQZr60+OL3RH3oDYCBxhudgHwCY6xuSHIbG8USnooR8rTHDIfRnXBGJnbY02SFbS+aFtbsZK0PHUUYcRDBYu+Fz0Sr30NO21Dtz/Lc6TSjqzLS7kxPeJPm4diPEEfORx8anpnJC7tv1Hfmj/LMfIhYQUBvXNSs8IiX0HbmlynJCnt/48TEACOkzWGVPhumqxFARtVDQWf/xfcPheSmfz0u8bLVfrdUbUbFDvdP8M+LnKOKCBumB634IgsAVRTe9g0C/C1pouwQbESp13/9f6kJEEWNCIOky67UZg8FgMBgMBoPBYDAYDAaDwWAwGAwGg8FgMBgMBoPBYDAYDAaDwWAwGAwG48/l/wCy56SCSbB+RAAAAABJRU5ErkJggg==" alt="avatar">
        </div>
        <div class="text" id="name">
            <div>
                <strong><?php echo $j['name']; ?> </strong>
                <div class="text-muted" id="location">
                    <i class="icon ion-ios-pin me-1"></i>
                    <?php echo $j['address']?>

                </div>
                <div class="text-muted" id="status">
                    <i class=""><iconify-icon icon="majesticons:chat-status" style="font-size: 15px;"></iconify-icon></i>
                    <?php if($j['status']==0){
                        echo "<span class='badge  bg-warning'><iconify-icon icon='mdi:receipt-text-pending'></iconify-icon> Pending</span>";
                    }
                    else if($j['status']==1){
                        echo "<span class='badge  bg-info'><iconify-icon icon='ic:baseline-verified-user'></iconify-icon></i> Verified</span>";  
                    }
                    else{
                        echo "<span class='badge  bg-success'><iconify-icon icon='ic:baseline-verified'></iconify-icon></i>  Aproved</span>";  
                    }?>
                    

                </div>
            </div>
        </div>
    </a>
<?php } ?>
<!-- * listview -->

</div> 
    <!-- appCapsule -->


     <!-- App Bottom Menu -->
   <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->


    <!-- Sidebar Menu -->
   
    <!-- * Sidebar Menu -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/search.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:25 GMT -->
</html>