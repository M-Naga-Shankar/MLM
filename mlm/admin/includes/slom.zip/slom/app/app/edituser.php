<?php 
session_start();
if(!isset($_SESSION['userId']))
{
  header("location:../index.php");
}
include 'config.php';

       $sl_id=mysqli_query($conn,"select * from application");				
        
if($conn==true){
    echo "ok done";
}
else{
    echo "no";
}
if(!empty($_POST))
{
	$date=date('d/m/y');
    date_default_timezone_set("Asia/Kolkata");
 
                  date_default_timezone_get();
                $time=date('h:i:s'); 
                $id=$_POST['id'];
                $name=$_POST['name'];
  
	$phone=$_POST['phone'];
	$address=$_POST['address'];
    $password=$_POST['password'];
    $email=$_POST['email'];
	$refer=1;
	
	$sql=mysqli_query($conn,"UPDATE `user` SET `username`='$name',`password`='$password',`email`='$email',`phone`='$phone',`location`='$address' WHERE id='$id' ");
	
	if($sql==true)
	{
    
		
    $uid=$userId;
    echo "ok done";
     header("Location:profile.php?status=1");
   
	}
	else
	{
		$status=2;
		 echo "no";
	
	      header("Location:profile.php?status=2");
	}
}

?>