<?php
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';
?>
 <?php  
   if(!empty($_GET['id'])){
             $userId=$_GET['id'];
         }
               $sl_id=mysqli_query($conn,"select * from application where id='$userId'");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
               ?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/social-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:28 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.25.0/font/bootstrap-icons.css">
<script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>

    <style>
    

    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    
    .modal-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      
      width: 90%;
      max-height:700px;
      overflow:scroll;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    
    .close:hover {
      color: #000;
    }
    
    .modal-button {
      padding: 10px 20px;
      background-color: #007BFF;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    .modal-button:hover {
      background-color: #0056b3;
    }
    
        </style>

</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="#" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle"> Detailed Application</div>
        <div class="right">
            <label for="searchInput" class="mb-0 icon ">
            </label>
        </div>
    </div>
    <!-- searchBox 
    <div id="searchBox">
        <form>
            <span class="inputIcon">
                <i class="icon ion-ios-search"></i>
            </span>
            <input type="text" class="form-control" id="searchInput" placeholder="Search...">
            <a href="javascript:;" class="toggleSearchbox closeButton">
                <i class="icon ion-ios-close-circle"></i>
            </a>
        </form>
    </div> -->
    <!-- * searchBox -->
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">
        
      

        <div class="appContent">

            <!-- profile detail -->
            <div class="profileDetail mt-2">
                <div class="profileBox">
                    <div class="image">
                        <img src="https://media.istockphoto.com/id/1369899988/vector/handshake-sign-in-the-circle-on-white-background-vector-illustration.jpg?s=612x612&w=0&k=20&c=auA4GuM2p-EmKmEgcFjIOUibPiXsuvTxfvRKB-EN7o8=" alt="avatar" class="avatar">
                    </div>
                    <div class="info" style="font-size:18px;">
                  <i>  <iconify-icon icon="icon-park-outline:edit-name" style="font-size: 20px;"></iconify-icon></i><span>Name :     <strong><?php echo "".$j['name']; ?></strong></span>
                  <br>
                  <i><iconify-icon icon="teenyicons:id-outline" style="font-size: 20px;"></iconify-icon> </i>
                    <span>  &nbsp;ID :  <strong> <?php echo "".$j['id']; ?></strong></span>
                        
                        
                    <br>
                  
                    </div>
                </div>
                <div class="bio" style="font-size:18px;">
               Phone : <strong> <?php echo "".$j['phone']; ?></strong>
                          <br> Need Type : <strong>
                         <?php if($j['type']==1){
                        echo "Educational";
                    }
                    else if($j['type']==2){
                        echo "Personal";
                    }
                    else{
                        echo "Physical";
                    }?> </strong>   
                    <br>
                    Status : 
                  <?php if($j['status']==0){
                        echo "<span class='badge  bg-warning'><iconify-icon icon='mdi:receipt-text-pending'></iconify-icon> Pending</span>";
                    }
                    else if($j['status']==1){
                        echo "<span class='badge  bg-info'><iconify-icon icon='ic:baseline-verified-user'></iconify-icon></i> Verified</span>";  
                    }
                    else{
                        echo "<span class='badge  bg-success'><iconify-icon icon='ic:baseline-verified'></iconify-icon></i>  Aproved</span>";  
                    }?>
                    </div>
                    <div class="divider mb-1 mt-1"></div>
                <div class="bio" style="font-size:18px;">
           <iconify-icon icon="material-symbols:info-outline" style="font-size: 20px;"></iconify-icon> &nbsp; <strong>Description : </strong><?php echo "".$j['discription']; ?> 
            </div>
</div>
               <div class="divider mb-1 mt-1"></div>
    
            <!-- * listview -->
<?php } ?>
    </div>
    <!-- appCapsule -->


    <!-- App Bottom Menu -->
    <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->

    <!-- Sidebar Menu -->
   
    <!-- * Sidebar Menu -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/social-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:28 GMT -->
</html>