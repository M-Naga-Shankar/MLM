<?php 
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';

       $sl_id=mysqli_query($conn,"select * from village_survey");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
              $sl_no=$j['id'];
           }
           $rq_no=$sl_no+1;
        
if($conn==true){
    echo "ok done";
}
else{
    echo "no";
}
if(!empty($_POST))
{
	$date=date('y/m/d');
    date_default_timezone_set("Asia/Kolkata");
 
                  date_default_timezone_get();
                $time=date('h:i:s'); 
    $name=$_POST['name'];  
	$dob=$_POST['dob']; 
    $region=$_POST['region'];
    $vName=$_POST['villageName'];
    $vPopu=$_POST['villagePopu'];
    $request=$_POST['requesttype'];
    $RPname=$_POST['RPname'];
	$number=$_POST['RPphone'];
    $pincode=$_POST['pincode'];
    $ref=$_SESSION['userid'];
	$subrefer=$_SESSION['ref'];
    
    
 
	$sql=mysqli_query($conn,"INSERT INTO `village_survey`(`time`, `date`, `refer`, `sub_refer`, `region`, `village_name`, `village_popu`,  `pincode`, `request_for`, `requested_by`, `request_phone`) VALUES ('$time','$date','$ref','$subrefer','$region','$vName','$vPopu','$pincode','$request','$RPname','$number')");

   	

	if($sql==true)
	{
    
		
    $uid=$userId;
    echo "ok done";
     header("Location:newapp.php?status=1");
   
	}
	else
	{
		$status=2;
		 echo "no";
	
	      header("Location:newapp.php?status=2");
	}
}

?>