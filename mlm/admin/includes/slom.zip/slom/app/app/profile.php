<?php $active=5;
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';
$id=$_SESSION['userid'];
 $sl_id=mysqli_query($conn,"select * from user where id='$id' ");					
					
echo $id;						    
 while($j=mysqli_fetch_array($sl_id))
 {

                    
                      $name= $j['username'];
                      $email= $j['email'];
                      $phone= $j['phone'];
                    $address=$j['location'];
                    $password=$j['password'];
 }
?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/social-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:28 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <style>
    

    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    
    .modal-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      
      width: 90%;
      max-height:700px;
      overflow:scroll;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    
    .close:hover {
      color: #000;
    }
    
    .modal-button {
      padding: 10px 20px;
      background-color: #007BFF;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    .modal-button:hover {
      background-color: #0056b3;
    }
    
        </style>
        <script>
            function openModal() {
      document.getElementById("modal").style.display = "block";
    }
    
    function closeModal() {
      document.getElementById("modal").style.display = "none";
    }
    
    // Close the modal if the user clicks outside the modal content
    window.onclick = function(event) {
      const modal = document.getElementById("modal");
      if (event.target === modal) {
        closeModal();
      }
    };
    
            </script>
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="#" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle">Profile</div>
        <div class="right">
           <a href="../logout.php"> <label  class="mb-0 icon ">
            <i class="icon ion-ios-log-out"></i>
            </label></a>
        </div>
    </div>
    <!-- searchBox -->
    <div id="searchBox">
        <form>
            <span class="inputIcon">
                <i class="icon ion-ios-search"></i>
            </span>
            <input type="text" class="form-control" id="searchInput" placeholder="Search...">
            <a href="javascript:;" class="toggleSearchbox closeButton">
                <i class="icon ion-ios-close-circle"></i>
            </a>
        </form>
    </div>
    <!-- * searchBox -->
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">
        <?php if(!empty($_GET['status'])){
    $status=$_GET['status'];
    
    if($status==1){
        ?>  
       <br>
        <div class="alert alert-success" role="alert">
        Successfully Edited
</div>
<?php 
    }
    
else{
        ?> 
        <br>
        <div class="alert alert-danger" role="alert">
  Error ! Incorrect Data Found
</div>
<?php 
    }
    
} ?>
            <!-- profile detail -->
            <div class="profileDetail mt-2">
                <div class="profileBox">
                    <div class="image">
                        <img src="assets/img/sample/avatar6.jpg" alt="avatar" class="avatar">
                    </div>
                    <div class="info">
                        <strong><?php echo $name; ?></strong>
                        <div class="text-muted">
                            <i class="icon ion-ios-pin"></i>
                            <?php echo $address; ?>
                        </div>
                    </div>
                </div>
               
                <div class="stats">
                    <div class="row">
                        <div class="col-6">
                            Phone<strong><?php echo $phone; ?></strong>
                        </div>
                        <div class="col-6">
                           Email<strong><?php echo $email; ?></strong>
                        </div>
                        
                    </div>
                </div>
                <div class="row pt-2 pb-2">
                    <div class="col" onclick="openModal()">
                        <a href="javascript:;" class="btn btn-primary btn-sm btn-block">
                            <i class="icon ion-ios-create" ></i>
                            Edit
                        </a>
                    </div>
                      
                    <div class="modal" id="modal<?php echo $j['id']; ?>">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Edit</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(<?php echo $j['id']; ?>)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
      <form action="edituser.php" method="POST">
        <div class="row g-3">
			<input required type="hidden" name="id" value="<?php echo $id; ?>">
  <div class=" col-12">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">User Name</label>
    <input required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $name; ?>" name="name">
  </div>


  <div class=" col-12">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Email</label>
    <input required type="email" class="form-control" id="exampleInputPassword1" value="<?php echo $email; ?>" name="email">
  </div>
  <div class=" col-12">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Phone</label>
    <input required type="number" class="form-control" id="exampleInputPassword1" value="<?php echo $phone; ?>" name="phone">
  </div>
  <div class=" col-12">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Password</label>
    <input required type="password" class="form-control" id="exampleInputPassword1" value="<?php echo $password; ?>" name="password">
  </div>
  <div class=" col-12">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Address</label>
    <input required type="text" class="form-control" id="exampleInputPassword1" value=" <?php echo $address; ?>" name="address">
  </div>
 
  <br>
  <div class="row">
  <button type="submit" class="btn btn-success col-3 m-3">Submit</button>
  <button type="reset" class="btn btn-danger col-3 m-3">Cancel</button>
           </div>
</form>
    </div>
  </div>
  </div>
  </div>
                   
            </div>
            <!-- * profile detail -->

            <div class="divider mt-2 mb-4"></div>
            <div class="sectionTitle mb-2">
                <div class="text-muted">Your</div>
                <div class="title">
                    <h1>Overview</h1>
                </div>
            </div>
            <!-- Iconed Box -->
            <div class="row">
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-warning">
                            <i class=""><iconify-icon icon="lucide:list-x" style="font-size: 30px; color:black;"></iconify-icon></i>
                        </div>
                        <div class="col">
                        <a href="" class="btn btn-warning btn-sm btn-block">
                            
                            Pending : 10
                        </a>
                    </div>
                    </div>
                </div>
                <!-- item -->
                <!-- item -->
                <div class="col-6">
                    <div class="iconedBox">
                        <div class="iconWrap bg-success">
                            <i class=""><iconify-icon icon="icon-park-outline:list" style="font-size: 30px; color:black;"></iconify-icon></i>
                        </div>
                        <div class="col">
                        <a href="" class="btn btn-success btn-sm btn-block">
                            
                       Aproved : 20 
                        </a>
                    </div>
                        
                    </div>
                </div>
                <!-- item -->
                <!-- item -->
             
                <!-- item -->
                <!-- item -->
               
                <!-- item -->
                 <!-- item -->
            
                <!-- item -->
                 <!-- item -->
                
                <!-- item -->
            </div>
            <!-- * Iconed Boxes -->
        </div>

    </div>
    <!-- appCapsule -->


    <!-- App Bottom Menu -->
    <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->

    <!-- Sidebar Menu -->
   
    <!-- * Sidebar Menu -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/social-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:28 GMT -->
</html>