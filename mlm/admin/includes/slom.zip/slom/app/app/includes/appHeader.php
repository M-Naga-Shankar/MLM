<div class="appHeader">
<div class="left">
            <a href="javascript:;" class="icon ">
              
            </a>
        </div>
        <div class="pageTitle">
            <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
            
            <img src="includes/logo.png" style="height:45px; width:45px; " class="image">
      <span style="font-family: Snell Roundhand; color:#00FF00; font-size:20px; font-weight:900;"> &nbsp;<i>S<span style="color:orange; font-size:25px;"><iconify-icon icon="carbon:tree"></iconify-icon></span>LOM</i> </span></div>
        <div class="right">
            <label for="searchInput" class="mb-0 icon toggleSearchbox">
             <!--   <i class="icon ion-ios-search"></i> -->
            </label>
        </div>
    </div>
    <!-- searchBox -->
    <div id="searchBox">
        <form>
            <span class="inputIcon">
                <i class="icon ion-ios-search"></i>
            </span>
            <input type="text" class="form-control" id="searchInput" placeholder="Search...">
            <a href="javascript:;" class="toggleSearchbox closeButton">
                <i class="icon ion-ios-close-circle"></i>
            </a>
        </form>
    </div>
    <!-- * searchBox -->