<?php $active=3; ?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:11 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

      <!-- App Header -->
      <div class="appHeader">
        <div class="left">
            <a href="javascript:;" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle">Projects</div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">


        <div class="carousel-single splide mt-2 mb-4">
                <div class="splide__track">
                    <ul class="splide__list">
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.php" class="card card-overlay text-white">
                                <img src="https://sriadityadevelopers.com/img/amoga_01.jpg" class="card-img img-fluid" alt="image">
                                <div class="card-img-overlay">
                                    <div class="header row">
                                        <div class="col-8" style="">@Panasapadu, Kakinada</div>
                                        <div class="col-4 text-end">
                                            <i class="icon ion-ios-heart"></i> 523
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h1>Amogha Smart City</h1>
                                        
                                    </div>
                                </div>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.php" class="card card-overlay text-white">
                                <img src="https://sriadityadevelopers.com/img/sarpavaram_construction.jpg" class="card-img img-fluid" alt="image">
                                <div class="card-img-overlay">
                                    <div class="header row">
                                        <div class="col-8">@Sarpavaram, Kakinada</div>
                                        <div class="col-4 text-end">
                                            <i class="icon ion-ios-heart"></i> 12K
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h1>Sri Pavitra Ventures</h1>
                                       
                                    </div>
                                </div>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.php" class="card card-overlay text-white">
                                <img src="https://sriadityadevelopers.com/img/under_construction.jpg" class="card-img img-fluid" alt="image">
                                <div class="card-img-overlay">
                                    <div class="header row">
                                        <div class="col-8">@Hamsavaram, Near Annavaram</div>
                                        <div class="col-4 text-end">
                                            <i class="icon ion-ios-heart"></i> 12K
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h1> Skanda</h1>
                                       
                                    </div>
                                </div>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.php" class="card card-overlay text-white">
                                <img src="https://sriadityadevelopers.com/img/sai_nivasam.jpg" class="card-img img-fluid" alt="image">
                                <div class="card-img-overlay">
                                    <div class="header row">
                                        <div class="col-8">@Karakuduru, Kakinada</div>
                                        <div class="col-4 text-end">
                                            <i class="icon ion-ios-heart"></i> 12K
                                        </div>
                                    </div>
                                    <div class="content">
                                        <h1>Sai Nivasam</h1>
                                       
                                    </div>
                                </div>
                            </a>
                        </li>
                        <!-- * slide -->
                    </ul>
                </div>
            </div>
            <!-- * Card Overlay Carousel -->



            <div class="divider mt-4 mb-2"></div>


            <!-- Button Carousel -->
            <div class="sectionTitle mb-2">
    <div class="text-muted">Our</div>
    <div class="title">
        <h1>Projects</h1>
        <a href="blog-category.html"></a>
    </div>
    <div class="lead">
    </div>
</div>
          
             <!-- post list -->
             <div class="row ">
                <!-- item -->
                <div class="col-6">
                    <a href="blog-post.php" class="postItem">
                    <div class="badge badge-success" style="margin-bottom:10px">Residential</div>
                   
                        <div class="imageWrapper">
                            
                            <img src="https://sriadityadevelopers.com/img/jewel-crest-logoslider.jpg" alt="image" class="image">
                            
                        </div>
                        
                        <h2 class="title">Jewel Crest</h2>
                       
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="col-6">
                    <a href="blog-post.php" class="postItem">
                    <div class="badge badge-primary" style="margin-bottom:10px">Commercial</div>
                   
                        <div class="imageWrapper">
                            <img src="https://sriadityadevelopers.com/img/amogha-smartcity-logoslider.jpg" alt="image" class="image">
                            
                        </div>
                        <h2 class="title">Amogha Smartcity</h2>
                     
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="col-6">
                    <a href="blog-post.php" class="postItem">
                    <div class="badge badge-danger" style="margin-bottom:10px">Industrial</div>
                   
                        <div class="imageWrapper">
                            <img src="https://sriadityadevelopers.com/img/vasudha-logoslider-1.jpg" alt="image" class="image">
                          
                        </div>
                        <h2 class="title">Vasudha Township</h2>
                    
                    </a>
                </div>
                <!-- * item -->
                <!-- item -->
                <div class="col-6">
                    <a href="blog-post.php" class="postItem">
                    <div class="badge badge-secondary" style="margin-bottom:10px">Residential</div>
                   
                        <div class="imageWrapper">
                            <img src="https://sriadityadevelopers.com/img/subhakari-homes-logoslider.jpg" alt="image" class="image">
                          
                        </div>
                        <h2 class="title">Subhakari Homes</h2>
                  
                    </a>
                </div>

                <!-- * item -->
                     <!-- item -->
                     <div class="col-6">
                    <a href="blog-post.php" class="postItem">
                    <div class="badge badge-warning" style="margin-bottom:10px">Institutional</div>
                   
                        <div class="imageWrapper">
                            <img src="https://sriadityadevelopers.com/img/coconut.jpg" alt="image" class="image">
                          
                        </div>
                        <h2 class="title">Coconut Garden</h2>
                  
                    </a>
                </div>
                
                <!-- * item -->
                     <!-- item -->
                     <div class="col-6">
                    <a href="blog-post.php" class="postItem">
                    <div class="badge badge-info" style="margin-bottom:10px">Residential</div>
                   
                        <div class="imageWrapper">
                            <img src="https://sriadityadevelopers.com/img/pavitra.jpg" alt="image" class="image">
                          
                        </div>
                        <h2 class="title">Sri Pavitra</h2>
                  
                    </a>
                </div>
                
                <!-- * item -->
            </div>
            <!-- * post list -->
           
<!-- * item list -->
        <!-- App Bottom Menu -->
   <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->
    <!-- * Sidebar Menu -->


    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:11 GMT -->
</html>