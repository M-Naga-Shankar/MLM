<?php $active=3; ?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/blog-post.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:11 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

      <!-- App Header -->
      <div class="appHeader">
        <div class="left">
            <a href="javascript:;" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle">Projects-Details</div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">

            <!-- title -->
            <h1 class="title-lg mt-2 mb-2">
                The World's Largest Pillow Fight is Also a Festival
            </h1>
            <!-- * title -->

            <!-- post header -->
            <div class="postHeader mb-2">
                <div>
                    <a href="#" class="badge badge-primary">Residential</a>
                </div>
                <div>
                    <img src="https://sriadityadevelopers.com/img/amoga_01.jpg" alt="avatar" class="avatar">
                    25 Sep 2019
                </div>
            </div>
            <!-- * post header-->

            <!-- post body -->
            <div class="postBody">

                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eget ligula efficitur, accumsan magna
                    vitae, lobortis turpis.
                </p>

                <figure>
                    <img src="https://sriadityadevelopers.com/img/amoga_01.jpg" alt="image">
                </figure>

                <p>
                    Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
                    Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Cras a
                    sem lacinia, cursus elit eu, tempor mi. Pellentesque nec semper nulla, in rhoncus metus. Etiam nisl
                    nisi, fermentum eu massa sit amet, euismod iaculis tellus.
                </p>
                <p>
                    Donec luctus, nibh id scelerisque mattis,
                    nunc enim dignissim felis, et interdum urna magna non nibh. Mauris id mi et purus consequat laoreet.
                    Aenean ullamcorper lobortis neque, non pulvinar purus. Aenean id feugiat orci. Nulla quis mattis
                    erat. Aenean et consectetur purus. Nullam volutpat venenatis volutpat. Nulla facilisi.
                </p>

                <figure>
                    <img src="https://sriadityadevelopers.com/img/sai_nivasam.jpg" alt="image">
                    <figcaption>
                        Aenean lorem odio, mollis sed consequat et, pellentesque id purus. Nunc sagittis malesuada
                        urna...
                    </figcaption>
                </figure>

                <p>
                    Aenean lorem odio, mollis sed consequat et, pellentesque id purus. Nunc sagittis malesuada urna,
                    ultricies lacinia nisi varius vitae. Aliquam sit amet egestas sapien, nec mollis quam.
                </p>

            </div>
            <!-- * post body -->

           <!-- author 
            <div class="postAuthor mt-3">
                <img src="assets/img/sample/avatar.jpg" alt="avatar" class="avatar">
                <div>
                    <strong>Olivia Eklund</strong>
                    <div class="text-muted">Tech Journalist</div>
                </div>
            </div> -->
            <!-- * author -->

            <!-- post buttons 
            <div class="row mt-2">
                <div class="col-6">
                    <a href="javascript:;" class="btn btn-primary btn-block">
                        <i class="icon ion-md-share"></i> Share
                    </a>
                </div>
                <div class="col-6">
                    <a href="javascript:;" class="btn btn-danger btn-block">
                        <i class="icon ion-ios-heart"></i> 1.2k
                    </a>
                </div>
            </div>-->
            <!-- * post buttons -->

            <div class="divider mt-2 mb-4"></div>

            <!-- related posts -->
            <div class="sectionTitle mb-2">
                <div class="title">
                    <h1>Related Projects</h1>
                </div>
            </div>
            <div class="carousel-multiple postCarousel splide">
                <div class="splide__track">
                    <ul class="splide__list">
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.html">
                                <img src="https://sriadityadevelopers.com/img/subhokari.jpg" alt="image" class="image">
                                <h2 class="title">subhokari Home</h2>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.html">
                                <img src="https://sriadityadevelopers.com/img/vasudha.jpg" alt="image" class="image">
                                <h2 class="title">Vasudha Township</h2>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.html">
                                <img src="https://sriadityadevelopers.com/img/sai_nivasam.jpg" alt="image" class="image">
                                <h2 class="title">Sai Nivasam</h2>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.html">
                                <img src="https://sriadityadevelopers.com/img/sai_nivasam.jpg" alt="image" class="image">
                                <h2 class="title">Sai Nivasam</h2>
                            </a>
                        </li>
                        <!-- * slide -->
                        <!-- slide -->
                        <li class="splide__slide">
                            <a href="blog-post.html">
                                <img src="https://sriadityadevelopers.com/img/sai_nivasam.jpg" alt="image" class="image">
                                <h2 class="title">Smart City</h2>
                            </a>
                        </li>
                        <!-- * slide -->
                    </ul>
                </div>
            </div>
            <!-- * related posts -->

         
            



    <!-- App Bottom Menu -->
    <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->
    <!-- Sidebar Menu -->
   
    <!-- * Sidebar Menu -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/blog-post.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:11 GMT -->
</html>