<?php $active=4;
session_start();
if(!isset($_SESSION['userid']))
{
  header("location:../index.php");
}
include 'config.php';
?>
<!doctype html>
<html lang="en">


<!-- Mirrored from bitter.bragherstudio.com/preview2/search.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:25 GMT -->
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bitter Mobile Template</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="Bitter Mobile Template">
    <meta name="keywords" content="bootstrap, mobile template, Bootstrap 5, mobile, html, responsive" />
    <link rel="icon" type="image/png" href="assets/img/icon/favicon.png" sizes="32x32">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/icon/192x192.png">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    
<script>
   
    $(document).ready(function () {
        $('#searchInput').on('input', function () {
            searchListItems();
        });
    });

    function searchListItems() {
        var input, filter, items, name, location, i;
        input = $('#searchInput').val().toUpperCase();
        items = $('.listItem');

        items.each(function () {
            name = $(this).find('#name strong').text().toUpperCase();
            location = $(this).find('#location').text().toUpperCase();
            status=$(this).find('#status').text().toUpperCase();

            if (name.indexOf(input) > -1 || location.indexOf(input) > -1|| status.indexOf(input)>-1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }
</script>
</head>

<body>

    <!-- Page loading -->
    <div id="loading">
        <div class="spinner-grow"></div>
    </div>
    <!-- * Page loading -->

    <!-- App Header -->
    <div class="appHeader">
        <div class="left">
            <a href="javascript:;" class="icon goBack">
                <i class="icon ion-ios-arrow-back"></i>
            </a>
        </div>
        <div class="pageTitle">Applications</div>
        <div class="right">
        </div>
    </div>
    <!-- * App Header -->

    <!-- App Capsule -->
    <div id="appCapsule">

        <div class="appContent">

        


            <div class="sectionTitle mt-4 mb-0">
                <div class="text-muted">View</div>
                <div class="title">
                    <h1>Applications</h1>
                </div>
            </div>
   <!-- * post list -->

   <div class="divider mt-1 mb-2"></div>

   <!-- Iconed Box -->
   <div class="row">
    
    
       <!-- item -->
       <!-- item -->
    
       <!-- item -->
   </div>
   <!-- * Iconed Boxes -->
          

 <!-- Iconed Box -->
 <div class="row">
                <!-- item -->
                <div class="col-6">
                   <a href="viewChild.php"> <div class="iconedBox">
                        <div class="iconWrap " style=" background: #00FF00;">
                            <i class=""><iconify-icon icon="mingcute:print-line" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title"> &nbsp;View Child &nbsp;Application</h4>
                        Click on the above icon to View application.
                        
                    </div>
                </div></a>
                
                <!-- item -->
                <div class="col-6">
                <a href="viewPregnant.php">       <div class="iconedBox">
                        <div class="iconWrap bg-warning" >
                            <i class=""><iconify-icon icon="mingcute:print-line" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">View Pregnant Application</h4>
                        Click on the above icon to View application.
                        
                    </div>
                </div></a>
                
                <!-- item -->
                <div class="col-6">
                <a href="viewWidow.php">      <div class="iconedBox">
                        <div class="iconWrap bg-success">
                            <i class=""><iconify-icon icon="mingcute:print-line" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">View Widow Application</h4>
                        Click on the above icon to View application.
                        
                    </div>
                </div></a>
                
                <!-- item -->
                <div class="col-6">
                <a href="viewAged.php">   <div class="iconedBox">
                        <div class="iconWrap bg-info" >
                            <i class=""><iconify-icon icon="mingcute:print-line" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">View Aged Woman Application</h4>
                        Click on the above icon to View application.
                        
                    </div>
                </div></a>
                
                <!-- item -->
                <div class="col-6">
                <a href="viewVillage.php">  <div class="iconedBox">
                        <div class="iconWrap bg-danger">
                            <i class=""><iconify-icon icon="mingcute:print-line" style="font-size: 30px;"></iconify-icon></i>
                        </div>
                        <h4 class="title">View Village Application</h4>
                        Click on the above icon to View application.
                        
                    </div>
                </div>
                
                <!-- item -->
                <!-- item -->

</div> 
    <!-- appCapsule -->


     <!-- App Bottom Menu -->
   <?php include 'includes/appBottomMenu.php' ?>
    <!-- * App Bottom Menu -->


    <!-- Sidebar Menu -->
   
    <!-- * Sidebar Menu -->

    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Bootstrap-->
    <script src="assets/js/lib/bootstrap.bundle.min.js"></script>
    <!-- Splide -->
    <script src="assets/js/plugins/splide/splide.min.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/app.js"></script>


</body>


<!-- Mirrored from bitter.bragherstudio.com/preview2/search.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 21 Jul 2023 13:48:25 GMT -->
</html>