<div class="appHeader">
<div class="left">
            <a href="javascript:;" class="icon ">
                <i class="icon ion-ios-menu"></i>
            </a>
        </div>
        <div class="pageTitle">
            <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
            
            <img src="https://media.istockphoto.com/id/1141219682/vector/handshake-sign-in-the-circle-on-white-background-vector-illustration.jpg?s=612x612&w=0&k=20&c=ETV2A6cXO_fBRMiaaR9NwAds0hT0fvlfRHqpXYuEV3k="  alt="aditya" style="height:45px; width:45px; border-radius:80%;" class="image">
      <span style="font-family: Georgia, serif; color:#0E86D4; font-size:18px; font-weight:900;"> Trust NGO </span></div>
        <div class="right">
            <label for="searchInput" class="mb-0 icon toggleSearchbox">
             <!--   <i class="icon ion-ios-search"></i> -->
            </label>
        </div>
    </div>
    <!-- searchBox -->
    <div id="searchBox">
        <form>
            <span class="inputIcon">
                <i class="icon ion-ios-search"></i>
            </span>
            <input type="text" class="form-control" id="searchInput" placeholder="Search...">
            <a href="javascript:;" class="toggleSearchbox closeButton">
                <i class="icon ion-ios-close-circle"></i>
            </a>
        </form>
    </div>
    <!-- * searchBox -->