<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
if(!isset($_SESSION['userId']))
{
  header("location:../index.php");
}
include 'includes/head.php';
include 'config.php';
$act=4;
?>
<body>
	<!-- side bar -->
	<?php 
include 'includes/sidebar.php';
?>
	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		
		<?php 
include 'includes/navbar.php';
?>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
		<?php if(!empty($_GET['status'])){
    $status=$_GET['status'];
    
    if($status==1){
        ?>  
       <br>
        <div class="alert alert-success" role="alert">
 Verified Successfully
</div>
<?php 
    }
    
else{
        ?> 
        <br>
        <div class="alert alert-danger" role="alert">
  Error ! Incorrect Data Found
</div>
<?php 
    }
    
} ?>
			<div class="head-title">
				<div class="left">
					<h1>
View Application</h1>
					<ul class="breadcrumb">
						<li>
View Application</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>

			<ul class="box-info">
				<li>
				<i class='bx bg-warning'><iconify-icon icon='mdi:receipt-text-pending' style='color:white'></iconify-icon></i>
					<span class="text">
						<h3>1020</h3>
						<p>Pending Applications</p>
					</span>
				</li>
				<li>
				<i class='bx bg-info' ><iconify-icon icon='ic:baseline-verified-user' style='color:white'></iconify-icon></i>
					<span class="text">
						<h3>2834</h3>
						<p>Verified Applications</p>
					</span>
				</li>
                <li>
				<i class='bx bg-success' ><iconify-icon icon='ic:baseline-verified' style='color:white'></iconify-icon> </i>
					<span class="text">
						<h3>2834</h3>
						<p>Aproved Applications</p>
					</span>
				</li>
			
			</ul>


			<div class="table-data ">
				<div class="container ">

				<div class="order">
					<div class="head">
						<h3>Recent Orders</h3>
						<i class='bx bx-search' ></i><span><input id="searchInput" type="text" class="form-control"></span>
						<i class='bx bx-filter' ></i>
					</div>
					<table >
						<thead>
							<tr>
                                 <th>ID</th>
								<th>Name</th>
								
								<th>Phone</th>
                                <th>Address</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Status</th>

							</tr>
						</thead>
						<tbody>
                        <?php  
$ref=$_SESSION['userId'];
               $sl_id=mysqli_query($conn,"select * from application where subrefer='$ref'");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
               ?>
							<tr>
                                <td style="text-align:center;"><?php echo $j['id']; ?></td>
								<td><?php echo $j['name'];?></td>
								<td><?php echo $j['phone'];?></td>
								<td><?php echo $j['address'];?></td>
                                <td><?php echo $j['type'];?></td>
                                <td><?php echo $j['discription'];?></td>
                                <td><?php if( $j['status']==0){

                             echo "<a href='verify.php?id=".$j['id']."><button type='button' class='btn btn-warning'><i><iconify-icon icon='mdi:receipt-text-pending'></iconify-icon></i> Verify </button></a>";
                                }
                                else if( $j['status']==1){

                                    echo "<button type='button' class='btn btn-info'><i ><iconify-icon icon='ic:baseline-verified-user'></iconify-icon></i> Verified </button>";
                                       }
                                else if($j['status']==2){
                                    echo "<button type='button' class='btn btn-success'><i ><iconify-icon icon='ic:baseline-verified'></iconify-icon></i> Aproved </button>";
                                }
                            ?>
</td>
							</tr>
					<?php } ?>		
						</tbody>
					</table>
				</div>
</div>
</div>
		<!--
    <div class="col-6 border m-2">
      <div class="p-3">Custom column padding</div>
    </div>
-->
  </div>
</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>