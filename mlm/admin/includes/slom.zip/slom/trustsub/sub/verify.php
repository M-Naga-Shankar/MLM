<?php 
session_start();
if(!isset($_SESSION['userId']))
{
  header("location:../index.php");
}

include 'config.php';

     			
        
if($conn==true){
    echo "ok done";
}
else{
    echo "no";
}
if(!empty($_GET))
{
                $id=$_GET['id'];
       
	
	$sql=mysqli_query($conn,"UPDATE `application` SET `status`=1 WHERE id='$id'");
	
	if($sql==true)
	{
    
    echo "ok done";
   header("Location:viewapp.php?status=1");
   
	}
	else
	{
		$status=2;
		 echo "no";
	
 header("Location:viewapp.php?status=2");
	}
}

?>