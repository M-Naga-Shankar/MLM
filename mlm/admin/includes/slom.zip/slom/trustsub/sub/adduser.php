<?php
session_start();
if (!isset($_SESSION['userId'])) {
    header("location:../index.php");
}

// adduser.php

// Include the database configuration file
require 'config.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize an array to store user data
    $userData = array();

    // Collect form data
    foreach ($_POST as $key => $value) {
        // Ensure the key is not empty and starts with a letter (to avoid potential security issues)
        if (!empty($key)) {
            // Sanitize and store the data
            $userData[$key] = mysqli_real_escape_string($conn, $value);
        }
    }

    // Check if there is any data to insert
    if (!empty($userData)) {
        // Build the SQL query to insert data into the database
        $columns = implode(',', array_map(function($column) {
            return "`$column`";
        }, array_keys($userData)));
        $values = "'" . implode("','", $userData) . "'";
        $query = "INSERT INTO `user` ($columns) VALUES ($values)";

        // Perform the query
        $result = mysqli_query($conn, $query);

        // Check if the query was successful
        if ($result) {
            // Redirect to createuser.php with a success status if needed
             header("Location:createuser.php?status=1");
            echo "done";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // Redirect to createuser.php with a different status if needed
         header("Location:createuser.php?status=2");
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    // Redirect to the form page if accessed directly without submitting the form
     header("Location:createuser.php");
    exit();
}
?>
