<?php
$act=1;
?>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->	
	<link rel="stylesheet" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
	<title>Trust</title>
	<style>
		li{
			list-style: none;
		}
		a {
  text-decoration: none;
}
#inputGroup-sizing-sm{
  color:black; font-weight:500; font-size:15px;
}
	</style>
	<style>

    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    
    .modal-content {
      background-color: #fff;
      padding: 20px;
      border-radius: 5px;
      position: absolute;
	  
      top: 40%;
      left: 50%;
	  
      transform: translate(-30%, -30%);
      
      width: 50%;
      max-height:700px;
      overflow:scroll;
    }
    
    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    
    .close:hover {
      color: #000;
    }
    
    .modal-button {
      padding: 10px 20px;
      background-color: #007BFF;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    .modal-button:hover {
      background-color: #0056b3;
    }
    
        </style>
        <script>
            function openModal(a) {
              
      document.getElementById("modal"+a).style.display = "block";
    }
    
    function closeModal(a) {
      document.getElementById("modal"+a).style.display = "none";
    }
    
    // Close the modal if the user clicks outside the modal content
    window.onclick = function(event) {
      const modal = document.getElementById("modal"+a);
      if (event.target === modal) {
        closeModal();
      }
    };
            </script>
              <script>
        $(document).ready(function () {
            $('#searchInput').on('input', function () {
                searchTable();
            });
        });

        function searchTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = $('#searchInput').val().toUpperCase();
            table = $('table');
            tr = table.find('tbody tr');

            tr.each(function () {
                td = $(this).find('td');
                var showRow = false;

                td.each(function () {
                    txtValue = $(this).text().toUpperCase();
                    if (txtValue.indexOf(input) > -1) {
                        showRow = true;
                        return false; // Break the inner loop if match found in this row
                    }
                });

                if (showRow) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }
    </script>
    
	<script src="script.js"></script>

</head>