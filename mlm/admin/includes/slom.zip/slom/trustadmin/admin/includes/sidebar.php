<!-- SIDEBAR -->
<section id="sidebar">
<center>
		<a href="#" class="brand" style="padding:10px; margin:30px;">
		
			<img src="includes/logo.png" style="height:120px; width:180px;" alt="">
			<span class="text" style="font-size:40px; color:#2EFF2E; font-family: Georgia, cursive;"></span>

		</a>
		</center>	<ul class="side-menu top">
			<li <?php if($act==1) { echo "class='active'"; }?>>
				<a href="profile.php">
					<i class='bx bxs-user bx-sm' ></i>
					<span class="text">Profile</span>
				</a>
			</li> 
			
			<li <?php if($act==2) { echo "class='active'"; }?>>
				<a href="createsub.php">
				<i class='bx  bx-sm' ><iconify-icon icon="material-symbols:person-add-outline"></iconify-icon></i>
					<span class="text">Create Sub Admin</span>
				</a>
			</li>
			<li <?php if($act==3) { echo "class='active'"; }?>>
				<a href="viewsub.php">
				<i class='bx  bx-sm'><iconify-icon icon="ic:outline-people"></iconify-icon></i>
					<span class="text">View Sub Admin</span>
				</a>
			</li>
			<li <?php if($act==4) { echo "class='active'"; }?>>
				<a href="viewuser.php">
				<i class='bx bx-list-ul bx-sm'></i>
					<span class="text">View volunteers</span>
				</a>
			</li>
			<li <?php if($act==5) { echo "class='active'"; }?>>
				<a href="viewStudent.php">
				<i class='bx bx-printer bx-sm' ></i>
					<span class="text">View Student Application</span>
				</a>
			</li>
			<li <?php if($act==6) { echo "class='active'"; }?>>
				<a href="viewPregnant.php">
				<i class='bx bx-printer bx-sm' ></i>
					<span class="text">View Pregnant Application</span>
				</a>
			</li>
			<li <?php if($act==7) { echo "class='active'"; }?>>
				<a href="viewWidow.php">
				<i class='bx bx-printer bx-sm' ></i>
					<span class="text">View Widow Application</span>
				</a>
			</li>
			<li <?php if($act==8) { echo "class='active'"; }?>>
				<a href="viewAged.php">
				<i class='bx bx-printer bx-sm' ></i>
					<span class="text">View Old Age Application</span>
				</a>
			</li>
			<li <?php if($act==9) { echo "class='active'"; }?>>
				<a href="viewVillage.php">
				<i class='bx bx-printer bx-sm' ></i>
					<span class="text">View Village Application</span>
				</a>
			</li>
		</ul>
		<ul class="side-menu">
			<li>
			<a href="../logout.php" class="logout">
					<i class='bx bxs-log-out-circle bx-sm' ></i>
					<span class="text">Logout</span>
				</a>
			</li>
		</ul>
	</section>
	<!-- SIDEBAR -->