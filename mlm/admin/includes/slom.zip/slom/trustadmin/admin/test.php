<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
if(!isset($_SESSION['userId']))
{
  header("location:../index.php");
}
include 'includes/head.php';
include 'config.php';
$act=4;
?>
<body>
	<!-- side bar -->
	<?php 
include 'includes/sidebar.php';
?>
	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		
		<?php 
include 'includes/navbar.php';
?>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
		<?php if(!empty($_GET['status'])){
    $status=$_GET['status'];
    
    if($status==1){
        ?>  
       <br>
        <div class="alert alert-success" role="alert">
 Verified Successfully
</div>
<?php 
    }
    
else{
        ?> 
        <br>
        <div class="alert alert-danger" role="alert">
  Error ! Incorrect Data Found
</div>
<?php 
    }
    
} ?>
			<div class="head-title">
				<div class="left">
					<h1>
View Student Application</h1>
					<ul class="breadcrumb">
						<li>
View Application</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>

			<ul class="box-info">
				<li>
				<i class='bx bg-warning'><iconify-icon icon='mdi:receipt-text-pending' style='color:white'></iconify-icon></i>
					<span class="text">
						<h3>1020</h3>
						<p>Pending Applications</p>
					</span>
				</li>
				<li>
				<i class='bx bg-info' ><iconify-icon icon='ic:baseline-verified-user' style='color:white'></iconify-icon></i>
					<span class="text">
						<h3>2834</h3>
						<p>Verified Applications</p>
					</span>
				</li>
                <li>
				<i class='bx bg-success' ><iconify-icon icon='ic:baseline-verified' style='color:white'></iconify-icon> </i>
					<span class="text">
						<h3>2834</h3>
						<p>Aproved Applications</p>
					</span>
				</li>
			
			</ul>


			<div class="table-data ">
				<div class="container ">

				<div class="order">
					<div class="head">
						<h3>Recent Orders</h3>
						<i class='bx bx-search' ></i><span><input id="searchInput" type="text" class="form-control"></span>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
                                 <th>ID</th>
                                 <th>Refer ID</th>
								<th>Name</th>
								<th>Phone</th>
                                <th>Classs</th>
                                <th>Pincode</th>    
                                <th>Status</th>

							</tr>
						</thead>
						<tbody>
                        <?php  
$ref=$_SESSION['userId'];
               $sl_id=mysqli_query($conn,"select * from student where sub_refer='$ref'");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
               ?>
							<tr>
                                <td style="text-align:center;"><?php echo $j['id']; ?></td>
                                <td><?php echo $j['refer'];?></td>
								<td><?php echo $j['student_name'];?></td>
								<td><?php echo $j['parent_contact'];?></td>
								<td><?php echo $j['class'];?></td>
                                <td><?php echo $j['pincode'];?></td>
                                <td><?php if( $j['status']==0){

echo "<button type='button' class='btn btn-warning'><i><iconify-icon icon='mdi:receipt-text-pending'></iconify-icon></i> Verify </button>";
   }
   else if( $j['status']==1){

       echo "<a href='#'><button type='button' onclick='openModal(".$j['id'].")' class='btn btn-primary'><i ><iconify-icon icon='ic:baseline-verified-user'></iconify-icon></i> Aproval </button> </a>";
          }
   else if($j['status']==2){
       echo "<button type='button' class='btn btn-success'><i ><iconify-icon icon='ic:baseline-verified'></iconify-icon></i> Aproved </button>";
   }
?>
</td>
                            <div class="modal" id="modal<?php echo $j['id']; ?>">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-8"><h4>Fill The Below Details</h4></div>
  <div class="col-4"> <span class="close" style="color:red; float:right;" onclick="closeModal(<?php echo $j['id']; ?>)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
      <form action="verifyStudent.php" method="POST">
        <div class="row g-3">
        <div class=" col-3">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Application ID</label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo "CH-".$j['id']; ?>">
                                <input type="hidden" value="<?php echo $j['id']; ?>" name="id">
</div>
  <div class=" col-9">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Student Full Name </label>
    <input readonly required type="text" name="student_name" class="form-control" id="exampleInputEmail1" value="<?php echo $j['student_name']; ?>" >
  </div>


  <div class=" col-6">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Date of Birth</label>
    <input readonly required type="date" class="form-control" id="exampleInputPassword1" value="<?php echo $j['dob']; ?>" name="dob">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Class</label>
    <input readonly required type="number" max="12" class="form-control" id="exampleInputEmail1" value="<?php echo $j['class']; ?>" name="class">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">School / Collage Name</label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $j['school_name']; ?>" name="school_name">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Gender</label><br><div style="display:flex">
  
  <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off">
<label class="btn btn-primary" for="btn-check"><?php echo $j['gender']; ?></label>


                            </div>
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Student Aadhar No</label>
    <input readonly required type="number" max="9999999999999999" class="form-control" id="exampleInputEmail1" value="<?php echo $j['child_adhar']; ?>" name="child_adhar">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Father Aadhar No</label>
    <input readonly required type="number" max="9999999999999999" class="form-control" id="exampleInputEmail1" value="<?php echo $j['father_adhar']; ?>" name="father_adhar">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Mother Aadhar No</label>
    <input readonly required type="number" max="9999999999999999" class="form-control" id="exampleInputEmail1" value="<?php echo $j['mother_adhar']; ?>" name="mother_adhar">
  </div>
  <div class=" col-6">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Phone</label>
    <input readonly required type="number" max="9999999999" class="form-control" id="exampleInputPassword1" value="<?php echo $j['parent_contact']; ?>" name="parent_contact">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Religious</label>
    <select class="form-select" aria-label="Default select example" name="religious">
  <option readonly value="Christianity"><?php echo $j['religious']; ?></option>

</select>
                            </div>
<div class=" col-6">
    <label for="exampleInputs" style="color:black; font-weight:600; font-size:18px; ">Caste / Subcaste</label>
    <input readonly required type="text"class="form-control" id="exampleInputs" value="<?php echo $j['caste']; ?>" name="caste">

  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Favorite Subject </label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $j['fav_subject']; ?>" name="fav_subject">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Favorite colour  </label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $j['fav_color']; ?>" name="fav_color">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Favorite Game  </label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $j['fav_game']; ?>" name="fav_game">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Hobbies  </label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $j['hobbies']; ?>" name="hobbies">
  </div>
  <div class=" col-6">
    <label for="exampleInputEmail1" style="color:black; font-weight:600; font-size:18px; ">Best Friend  </label>
    <input readonly required type="text" class="form-control" id="exampleInputEmail1" value="<?php echo $j['best_friend']; ?>" name="best_friend">
  </div>



  <div class=" col-6">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Become in future </label>
    <input readonly required type="text" class="form-control" id="exampleInputPassword1" value=" <?php echo $j['goal']; ?>" name="goal">
  </div>
  <div class=" col-8">
    <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Full Address </label>
    <textarea readonly class="form-control" id="floatingTextarea2" style="height: 100px" name="address"><?php echo $j['address']; ?></textarea>

  </div>
  <div class=" col-1">
                            </div>
  <div class=" col-3">
  <label for="exampleInputPassword1" style="color:black; font-weight:600; font-size:18px; ">Photo</label>
  <div class="image">
            <img src="http://localhost/trust/app/app/student/<?php echo $j['photo'];?>" alt="avatar" style="height:100px; width:100px; border-radius:0%; padding:5px; border:solid black 2px;">
        </div>
</div>
  <br>
  <div class="row" >
  <div class=" col-4"  style="padding:40px 0%; "><center>
<a href="aproveStudent.php?id=<?php echo $j['id'];?>"  <button type="button" class="btn btn-success col-6 mt-4">Aproval</button>
</a>                    </center>         </div>
                            <div class=" col-4"  style="padding:40px 0%; "><center>
                            <button type="reset" class="btn btn-danger col-6 mt-4">Reject</button>   

                            </center>    
                            </div>
                            <div class="col-4" style="padding:40px 0%;">
                                <center>
                                <button type="button"  onclick="printModal(<?php echo $j['id']; ?>)" class="btn btn-primary col-6 mt-4">Print</button>
                                </center>
                            </div>
 
           </div>
</form>
    </div>
  </div>
</div>
</td>
							</tr>
					<?php } ?>		
						</tbody>
					</table>
				</div>
</div>
</div>
		<!--
    <div class="col-6 border m-2">
      <div class="p-3">Custom column padding</div>
    </div>
-->
  </div>
</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>