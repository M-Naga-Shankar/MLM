<?php 
session_start();
if(!isset($_SESSION['aId']))
{
  header("location:../index.php");
}

include 'config.php';

     			
        
if($conn==true){
    echo "ok done";
}
else{
    echo "no";
}
if(!empty($_GET))
{
                $id=$_GET['id'];
                $status=$_GET['status'];
       
	
	$sql=mysqli_query($conn,"UPDATE `widow_aged` SET `status`=$status WHERE id='$id'");
	
	if($sql==true)
	{
    if($status==3){
        header("Location:viewAged.php?status=3");
    }
    else{
    echo "ok done";
     header("Location:viewAged.php?status=1");
    }
	}
	else
	{
		$status=2;
		 echo "no";
	
	      header("Location:viewAged.php?status=2");
	}
}

?>