<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
if(!isset($_SESSION['aId']))
{
  header("location:../index.php");
}
include 'includes/head.php';
include 'config.php';
$act=7;
?>
<body>
	<!-- side bar -->
	<?php 
include 'includes/sidebar.php';
?>
	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		
		<?php 
include 'includes/navbar.php';
?>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
		<?php if(!empty($_GET['status'])){
    $status=$_GET['status'];
    
    if($status==1){
      ?>  
     <br>
      <div class="alert alert-success" role="alert">
Aproved Successfully
</div>
<?php 
  }
    
  else  if($status==3){
        ?>  
       <br>
        <div class="alert alert-warning" role="alert">
Rejected Successfully
</div>
<?php 
    }  
  
else{
      ?> 
      <br>
      <div class="alert alert-danger" role="alert">
Error ! Incorrect Data Found
</div>
<?php 
  }
  
} ?>
			<div class="head-title">
				<div class="left">
					<h1>
View Widow Application</h1>
					<ul class="breadcrumb">
						<li>
View Application</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>

			<ul class="box-info">
				<li>
				<i class='bx bg-warning'><iconify-icon icon='mdi:receipt-text-pending' style='color:white'></iconify-icon></i>
					<span class="text">
						<h3>1020</h3>
						<p>Pending Applications</p>
					</span>
				</li>
				<li>
				<i class='bx bg-info' ><iconify-icon icon='ic:baseline-verified-user' style='color:white'></iconify-icon></i>
					<span class="text">
						<h3>2834</h3>
						<p>Verified Applications</p>
					</span>
				</li>
                <li>
				<i class='bx bg-success' ><iconify-icon icon='ic:baseline-verified' style='color:white'></iconify-icon> </i>
					<span class="text">
						<h3>2834</h3>
						<p>Aproved Applications</p>
					</span>
				</li>
			
			</ul>


			<div class="table-data ">
				<div class="container ">

				<div class="order">
					<div class="head">
						<h3>List</h3>
						<i class='bx bx-search' ></i><span><input id="searchInput" type="text" class="form-control"></span>
						<i class='bx bx-filter' ></i>
					</div>
					<table>
						<thead>
							<tr>
                                 <th>ID</th>
                                 <th>Refer ID</th>
								<th>Pregnant Name</th>
								<th>Phone</th>
                                <th>Husband Name</th>
                                <th>Pincode</th>    
                                <th>Status</th>

							</tr>
						</thead>
						<tbody>
                        <?php  
$ref=$_SESSION['userId'];
               $sl_id=mysqli_query($conn,"select * from widow_aged where status>0 and app_type=0 ORDER BY id DESC");					
					
						    
           while($j=mysqli_fetch_array($sl_id))
           {
               ?>
							<tr>
                                <td style="text-align:center;"><?php echo "WI-".$j['id']; ?></td>
                                <td><?php echo $j['refer'];?></td>
								<td><?php echo $j['name'];?></td>
								<td><?php echo $j['phone'];?></td>
								<td><?php echo $j['husband_name'];?></td>
                                <td><?php echo $j['pincode'];?></td>
                                <td><?php if( $j['status']==0){

echo "<button type='button' class='btn btn-warning'><i><iconify-icon icon='mdi:receipt-text-pending'></iconify-icon></i> Verify </button>";
   }
   else if( $j['status']==1){

       echo "<a href='#'><button type='button' onclick='openModal(".$j['id'].")' class='btn btn-primary'><i ><iconify-icon icon='ic:baseline-verified-user'></iconify-icon></i> Aproval </button> </a>";
          }
   else if($j['status']==2){
       echo "<button type='button' onclick='openModal(".$j['id'].")' class='btn btn-success'><i ><iconify-icon icon='ic:baseline-verified'></iconify-icon></i> Aproved </button>";
   }  else if($j['status']==3){
    echo "<button type='button' onclick='openModal(".$j['id'].")' class='btn btn-danger'><i ><iconify-icon icon='tabler:x'></iconify-icon></i> Rejected </button>";
}
?>
</td>
                            <div class="modal" id="modal<?php echo $j['id']; ?>">
                <div class="container-fluid">
    <div class="modal-content">
    <div class="row">
  <div class="col-11"><center><h4>Widow Women Details<center></h4></div>
  <div class="col-1" id='close'> <span class="close" style="color:red; float:right;" onclick="closeModal(<?php echo $j['id']; ?>)">&times;</span>
      </div>
</div>
<div style="display:flex; ">
      
      
     
      <br>
</div>
      <form action="verifyAged.php" method="POST">
      <?php
	$date=date('d/m/y');
    date_default_timezone_set("Asia/Kolkata");
 
                  date_default_timezone_get();
                $time=date('h:i:s');
  echo "<input type='hidden' name='status' value='1'>";
  echo "<input type='hidden' name='sub_refer' value='{$ref}'>";

	   $query = "SELECT * FROM `widow_aged` WHERE `id` = ".$j['id'];

		$result = mysqli_query($conn, $query);
			$row = mysqli_fetch_assoc($result);
$flag=0;

                foreach ($row as $key => $value) {
					$flag=$flag+1;
          if ($flag==1)
          {
            echo "<div class='row' >";
              echo "<div class='col-9'>";
            echo "<div class='input-group input-group-sm mb-3'>";
            echo " <span style='width:230px;' class='input-group-text' id='inputGroup-sizing-sm'>ID </span> ";
            echo "<input type='text' readonly   class='form-control' id='{$key}' name='{$key}' value='CH-{$value}' required>";
            echo "</div>";
            echo "<input type='hidden' name='id' value='".$j['id']."'>";
          }
					else if($flag>6 && $flag<29){
       
            if($flag==7){
             
              
              echo "<div class='input-group input-group-sm mb-3'>";
              echo " <span style='width:230px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
              echo "<input type='text'  class='form-control' id='{$key}' name='{$key}' value='{$value}' required>";
              echo "</div>";
              echo "</div>";
              echo "<div class='col-3'>";
              echo " <div class='image'>
              <img src='../../app/app/pregnant/".$j['photo']."' alt='NULL' style='height:100px; width:100px; border-radius:5%; padding:5px; border:solid black 2px;'>
          </div>";
          echo "<br>";
              echo "</div>";
             
            }
            else if($flag==8 || $flag==11 ){
              echo "<div class='input-group input-group-sm mb-3'>";
              echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
              echo "<input type='date'   class='form-control' id='{$key}' name='{$key}' value='{$value}' required>";
              echo "</div>";
            }
            else if($flag==9 ){
              echo "<div class='input-group input-group-sm mb-3'>";
              echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
              echo "<input type='text' pattern='[0-9]{12}'  class='form-control' id='{$key}' name='{$key}' value='{$value}' required>";
            
              echo "</div>";
            }
            else if($flag==12 ){
              echo "<div class='input-group input-group-sm mb-3'>";
              echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
              echo "<input type='number'  class='form-control' id='{$key}' name='{$key}' value='{$value}' required>";
            
              echo "</div>";
            }
            else if($flag==25 ){
              echo "<div class='input-group input-group-sm mb-3'>";
              echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
              echo "<select class='form-select' id='{$key}' name='{$key}' required> <option>VILLAGE SURVY</option><option>PHONE CALL</option><option>LETTER</option><option>VDIRECT OFFICE VISIT</option> </select>";
              echo "</div>";
            }
            else if($flag==15 ){
              echo "<div class='input-group input-group-sm mb-3'>";
              echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
              echo "<select class='form-select' id='{$key}' name='{$key}' required> <option>YES</option><option>NO</option> </select>";
              echo "</div>";
            }
          
                  
               
                    else if($flag==24|| $flag==28){
                      echo "<div class='input-group input-group-sm mb-3'>";
                      echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
                      echo "<input type='text' pattern='[0-9]{10}' class='form-control' id='{$key}' name='{$key}' value='{$value}' required>";
                      echo "</div>";
                    }else{
                      echo "<div class='input-group input-group-sm mb-3'>";
                      echo " <span style='width:250px;' class='input-group-text' id='inputGroup-sizing-sm'>{$key} </span> ";
                      echo "<input type='text' class='form-control' id='{$key}' name='{$key}' value='{$value}' required>";
                      echo "</div>";
                    }

                    
					}
                }
    

            // Close the database connection
        
        ?>
  <div class="row" id="not" >
  <div class=" col-4"  style="padding:40px 0%; "><center>
<a href="aproveWidow.php?id=<?php echo $j['id'];?>&status=2">  <button type="button" class="btn btn-success col-6 mt-4"><iconify-icon icon='ic:baseline-verified'></iconify-icon><span>Aproval</span></button>
</a>                    </center>         </div>
                            <div class=" col-4"  style="padding:40px 0%; "><center>
                            <a href="aprovewidow.php?id=<?php echo $j['id'];?>&status=3">       <button type="button" class="btn btn-danger col-6 mt-4"><iconify-icon icon="healthicons:x-negative"></iconify-icon> Reject</button>   
  </a>
                            </center>    
                            </div>
                            <div class="col-4" style="padding:40px 0%;">
                                <center>
                                <button type="button"  onclick="printModal(<?php echo $j['id']; ?>)" class="btn btn-primary col-6 mt-4"><iconify-icon icon="ic:round-print"></iconify-icon> Print</button>
                                </center>
                            </div>
 
           </div>
</form>
    </div>
  </div>
</div>
</td>
							</tr>
					<?php } ?>		
						</tbody>
					</table>
				</div>
</div>
</div>
		<!--
    <div class="col-6 border m-2">
      <div class="p-3">aCustom column padding</div>
    </div>
-->
  </div>
</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
  <script>
function printModal(a) {
    var modalContent = document.getElementById('modal' + a);
    var ngo = prompt("Enter NGO Name");

    // Open a new window with the modal content
    var printWindow = window.open('', '_blank');
    printWindow.document.write('<html><head><title>Print</title>');
    printWindow.document.write('<link rel="stylesheet" type="text/css" href="style.css">');
    printWindow.document.write('<style>');
    printWindow.document.write('html, body { margin: 0; padding: 0; font-size: 12px; }'); // Adjust font size
    printWindow.document.write('@page { size: A4; margin: 0; }');
    printWindow.document.write('body { font-family: Arial, sans-serif; margin: 1cm; padding: 20px; }');
    printWindow.document.write('#not,#close { display:none; }'); // Adjust padding
    printWindow.document.write('.row { page-break-inside: avoid; }');
    printWindow.document.write('</style>');
    printWindow.document.write("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN' crossorigin='anonymous'>");  // Include your styles
    printWindow.document.write('</head><body>');
    printWindow.document.write("<center><div class='row'><div class='col-11'><h2>" + ngo + " NGO</h2></div></div></center>");
    printWindow.document.write(modalContent.innerHTML);
    printWindow.document.write("<br><div class='row'><div class='col-6'>Date </div><div class='col-6'>Place :</div><br><div class='col-6'> Applicant Signature :</div><div class='col-6'></div></div>");
    printWindow.document.write('<span>Note</b> : Applicant  Aadhar Card Xerox Copy Should Be attached to this Application</span>');
    printWindow.document.write('</body></html>');
    printWindow.document.close();

    // Wait for content to be loaded before printing
    printWindow.onload = function () {
        printWindow.print();
        printWindow.close();
    };
}




</script>

	<script src="script.js"></script>
</body>
</html>