<!DOCTYPE html>
<html lang="en">
<?php 
session_start();
if(!isset($_SESSION['aId']))
{
  header("location:../index.php");
}
include 'config.php';

include 'includes/head.php';
$act=2;
?>
<body>
	<!-- side bar -->
	<?php 
include 'includes/sidebar.php';
?>
	<!-- CONTENT -->
	<section id="content">
		<!-- NAVBAR -->
		
		<?php 
include 'includes/navbar.php';
?>
		<!-- NAVBAR -->

		<!-- MAIN -->
		<main>
        <?php if(!empty($_GET['status'])){
    $status=$_GET['status'];
    
    if($status==1){
        ?>  
       <br>
        <div class="alert alert-success" role="alert">
  Submited Successfully
</div>
<?php 
    }
    
else{
        ?> 
        <br>
        <div class="alert alert-danger" role="alert">
  Error ! Incorrect Data Found
</div>
<?php 
    }
    
} ?>

			<div class="head-title">
				<div class="left">
					<h1>
Create Admin</h1>
					<ul class="breadcrumb">
						<li>
							<a href="#">
Create Admin</a>
						</li>
						<li><i class='bx bx-chevron-right' ></i></li>
						<li>
							<a class="active" href="#">Home</a>
						</li>
					</ul>
				</div>
				
			</div>

			<ul class="box-info">
				<li>
				<i class='bx bx-group'></i>
					<span class="text">
						<h3>1020</h3>
						<p>Total Volunteers</p>
					</span>
				</li>
				<li>
				<i class='bx bx-list-check' ></i>
					<span class="text">
						<h3>2834</h3>
						<p>Total Applications</p>
					</span>
				</li>
			
			</ul>


			<div class="table-data ">
				<div class="container ">
  <div class="row p-3 ">
    <div class="col-12 border p-5 rounded-5">

<form class="row g-3 " action="adduser.php" method="POST" >
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">User Name</label>
    <input required type="text" class="form-control" id="inputEmail4" name="username">
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Email</label>
    <input required type="text" class="form-control" id="inputPassword4" name="email">
  </div>
  <div class="col-md-6">
    <label for="inputAddress" class="form-label">Phone</label>
    <input required type="number" class="form-control" id="inputAddress" placeholder="" name="phone">
  </div>
 
  <div class="col-md-6">
    <label for="inputCity" class="form-label">Password</label>
    <input required type="password" class="form-control" id="inputCity" name="password">
  </div>
  <div class="col-md-12">
    <label for="inputCity" class="form-label">Address</label>
    <input required type="text" class="form-control" id="inputCity" name="address">
  </div>
  <div class="col-6">
    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
  <div class="col-6">
    <button type="reset" class="btn btn-danger">Clear</button>
  </div>
</form>
</div>
</div>
		<!--
    <div class="col-6 border m-2">
      <div class="p-3">Custom column padding</div>
    </div>
-->
  </div>
</div>
			</div>
		</main>
		<!-- MAIN -->
	</section>
	<!-- CONTENT -->
	

	<script src="script.js"></script>
</body>
</html>