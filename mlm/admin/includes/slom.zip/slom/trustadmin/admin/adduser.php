<?php 
session_start();
if(!isset($_SESSION['aId']))
{
  header("location:../index.php");
}
include 'config.php';

       $sl_id=mysqli_query($conn,"select * from application");				
        
if($conn==true){
    echo "ok done";
}
else{
    echo "no";
}
if(!empty($_POST))
{
	$date=date('d/m/y');
    date_default_timezone_set("Asia/Kolkata");
 
                  date_default_timezone_get();
                $time=date('h:i:s'); 
                $name=$_POST['username'];
  
	$phone=$_POST['phone'];
	$address=$_POST['address'];
    $password=$_POST['password'];
    $email=$_POST['email'];
	
	$sql=mysqli_query($conn,"INSERT INTO `subadmin`( `date`, `time`, `username`, `password`, `email`, `phone`, `location`) VALUES ('$date','$time','$name','$password','$email','$phone','$address')");
	
	if($sql==true)
	{
    
		
    $uid=$userId;
    echo "ok done";
     header("Location:createsub.php?status=1");
   
	}
	else
	{
		$status=2;
		 echo "no";
	
	      header("Location:createsub.php?status=2");
	}
}

?>