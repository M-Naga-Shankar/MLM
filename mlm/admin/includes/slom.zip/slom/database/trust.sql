-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 28, 2023 at 10:55 AM
-- Server version: 8.0.17
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trust`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `location` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`, `phone`, `location`) VALUES
(1, 'shankar', '1234', 'asdf@com', '9989', ' kakinada');

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `id` int(10) NOT NULL,
  `refer` varchar(10) NOT NULL,
  `subrefer` varchar(10) NOT NULL,
  `date` varchar(15) NOT NULL,
  `time` varchar(15) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(40) NOT NULL,
  `type` int(10) NOT NULL,
  `discription` varchar(50) NOT NULL,
  `photo` varchar(40) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`id`, `refer`, `subrefer`, `date`, `time`, `name`, `phone`, `address`, `type`, `discription`, `photo`, `status`) VALUES
(1, '1', '1', '16/12/23', '01:37:29', 'sh', '9999999999', 'kakinada', 1, 'inter', '', 2),
(2, '2', '1', '16/12/23', '01:39:31', 'naga', '9999999999', 'divili', 2, 'inter', '', 2),
(3, '3', '1', '16/12/23', '01:51:36', 'shankarr', '9999999999', 'kakinada', 2, 'inter', '', 2),
(4, '1', '1', '16/12/23', '01:56:10', 'shankarr', '9999999999', 'kakinada', 3, 'inter', '', 2),
(5, '3', '1', '16/12/23', '12:30:42', 'shanlert', '9999999999', 'ekado', 1, 'some help', '', 1),
(6, '3', '1', '17/12/23', '11:05:47', 'sdfg', '9999999999', 'kakinada', 1, 'sme help', '', 1),
(7, '3', '1', '17/12/23', '11:06:41', 'nenu', '998989896', 'divili', 2, 'some loan', '', 1),
(8, '6', '1', '24/12/23', '03:49:13', 'Rahesh', '7386494983', 'Kkd', 1, '', '', 0),
(9, '6', '1', '25/12/23', '01:57:07', '', '', '34', 0, '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pregnant`
--

CREATE TABLE `pregnant` (
  `id` int(100) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `refer` varchar(10) NOT NULL,
  `sub_refer` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `adhar` varchar(15) NOT NULL,
  `education` varchar(40) NOT NULL,
  `husband_name` varchar(50) NOT NULL,
  `delivery_date` varchar(15) NOT NULL,
  `marrage_date` varchar(15) NOT NULL,
  `no_child` int(10) NOT NULL,
  `h_problem` varchar(40) NOT NULL,
  `living_status` varchar(20) NOT NULL,
  `village` varchar(20) NOT NULL,
  `street` varchar(20) NOT NULL,
  `mandal` varchar(20) NOT NULL,
  `district` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `requested` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `request_by` varchar(40) NOT NULL,
  `request_place` varchar(40) NOT NULL,
  `request_phone` varchar(15) NOT NULL,
  `status` int(10) NOT NULL,
  `photo` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pregnant`
--

INSERT INTO `pregnant` (`id`, `time`, `date`, `refer`, `sub_refer`, `name`, `dob`, `adhar`, `education`, `husband_name`, `delivery_date`, `marrage_date`, `no_child`, `h_problem`, `living_status`, `village`, `street`, `mandal`, `district`, `state`, `pincode`, `phone`, `requested`, `request_by`, `request_place`, `request_phone`, `status`, `photo`) VALUES
(1, '10:31:30', '25/12/23', '3', '1', 'some', '2023-12-25', '56', '5', 'evado', '2023-12-03', '2023-12-27', 5, 'freaver', 'Living Together', 'mlk', 'main', 'kir', 'East Godavari', 'Andhra Pradesh', '544544', '9989898989', 'Chris', 'hi', 'kkd', '999999999', 1, '1.png'),
(2, '09:21:30', '26/12/23', '3', '1', 'avaro', '2023-12-26', '56', '2', 'EVADO', '2023-12-03', '2023-12-27', 10, 'freaver', 'Living Together', 'mlk', 'main', 'kir', 'Vizianagaram', 'Andhra Pradesh', '555555', '998888888', 'Chris', 'hi', 'kkd', '999999999', -1, '1.png'),
(3, '09:27:37', '26/12/23', '3', '1', 'some', '2023-12-26', '203', '', 'evado', '', '2023-12-27', 10, 'freaver', 'living', 'mlko', 'mains', 'kir', 'Nellore', 'Andhra Pradesh', '253526', '989898989', 'Islam', 'hi', 'kkd', '999999999', 2, '1.png'),
(4, '09:30:43', '26/12/23', '3', '1', 'some23', '2023-12-26', '', '', 'edho', '2023-12-03', '', 0, '', 'living', '', '', '', '', '', '533533', '9999999999', '', '', '', '', 0, '1.png'),
(5, '09:57:14', '26/12/23', '3', '1', 'shankar', '2023-11-28', '', '', 'evado', '2008', '', 0, '', 'living', '', '', '', '', '', '555555', '9989898989', '', '', '', '', 0, '1.png'),
(6, '09:57:35', '26/12/23', '3', '1', 'shankar', '2023-11-28', '856', '5', 'evado', '2023-12-27', '2023-12-27', 100, 'freaver', 'Living Together', 'mlko', 'mainsp', 'kir', 'West Godavari', 'Andhra Pradesh', '555555', '9989898989', 'Lette', 'hip', 'kkd', '999999999', -1, '1.png'),
(7, '09:58:10', '26/12/23', '3', '1', 'shankar', '2023-11-28', '', '', 'evado', '2023-12-03', '', 0, '', '', '', '', '', '', '', '555555', '9989898989', '', '', '', '', 0, '1.png'),
(8, '10:01:14', '23/12/26', '3', '1', 'shankar', '2023-11-28', '', '', 'evado', '2023-12-03', '', 0, '', '', '', '', '', '', '', '555555', '9989898989', '', '', '', '', 0, '1.png');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(30) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `refer` varchar(10) NOT NULL,
  `sub_refer` varchar(10) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `class` varchar(10) NOT NULL,
  `school_name` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `child_adhar` varchar(20) NOT NULL,
  `father_adhar` varchar(20) NOT NULL,
  `mother_adhar` varchar(20) NOT NULL,
  `religious` varchar(10) NOT NULL,
  `caste` varchar(20) NOT NULL,
  `fav_subject` varchar(20) NOT NULL,
  `fav_color` varchar(20) NOT NULL,
  `fav_game` varchar(20) NOT NULL,
  `best_friend` varchar(30) NOT NULL,
  `hobbies` varchar(40) NOT NULL,
  `goal` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `parent_contact` varchar(15) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `photo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `time`, `date`, `refer`, `sub_refer`, `student_name`, `dob`, `class`, `school_name`, `gender`, `child_adhar`, `father_adhar`, `mother_adhar`, `religious`, `caste`, `fav_subject`, `fav_color`, `fav_game`, `best_friend`, `hobbies`, `goal`, `address`, `pincode`, `parent_contact`, `status`, `photo`) VALUES
(1, '10:08:42', '25/12/23', '3', '1', 'nagu', '2023-12-04', '10', 'machihu', 'MALE', '3', '4', '0', 'Islam ', 'bc,ob', 'science', 'blue', 'koko', 'lala', 'reading', ' terrorist', 'gf\\r\\nko', '533533', '998989898', 2, '2.png'),
(2, '12:42:30', '23/12/26', '3', '1', 'shankar1', '2023-12-13', '9', 'machi', 'FEMALE', '354', '253', '445', 'Other', 'sdf', 'science', 'white', 'koko', 'lala', 'reading', ' terrorist', 'kkd', '555555', '998989896', 1, '2.png');

-- --------------------------------------------------------

--
-- Table structure for table `subadmin`
--

CREATE TABLE `subadmin` (
  `id` int(10) NOT NULL,
  `date` varchar(15) NOT NULL,
  `time` varchar(15) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `location` varchar(30) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subadmin`
--

INSERT INTO `subadmin` (`id`, `date`, `time`, `username`, `password`, `email`, `phone`, `location`, `status`) VALUES
(1, '16/12/23', '09:50:55', 'shankar', '1234', 'asdf@com', '998999999999', '  kakinada', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `refer` varchar(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `location` varchar(30) NOT NULL,
  `status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `date`, `time`, `refer`, `username`, `password`, `email`, `phone`, `location`, `status`) VALUES
(1, '16/12/23', '07:39:31', '1', 'shankarnaga', '1234', 'logger@gmail.co', '99898989', '     klm', 0),
(2, '16/12/23', '07:41:05', '1', 'sdknfc', '1234', 'asca@com', '9', ' kakinada', 0),
(3, '16/12/23', '07:41:28', '1', 'shan', '1234', 'som12e@com', '98768787878', '   kkd', 0),
(4, '16/12/23', '11:31:56', '1', 'shankarrs', '1234', 'asca@com', '12345', 'ekad', 0),
(5, '17/12/23', '11:16:39', '1', 'shanka', '1234', 'asca@com', '9989999999', 'kakinada', 0),
(6, '17/12/23', '11:20:27', '1', 'shankar', '1234', 'asca@com', '9999999999', 'samarakota', 0);

-- --------------------------------------------------------

--
-- Table structure for table `village_survey`
--

CREATE TABLE `village_survey` (
  `id` int(100) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `refer` varchar(10) NOT NULL,
  `sub_refer` varchar(10) NOT NULL,
  `region` varchar(10) NOT NULL,
  `village_name` varchar(30) NOT NULL,
  `village_popu` varchar(10) NOT NULL,
  `panchayat_name` varchar(30) NOT NULL,
  `panchayat_popu` varchar(10) NOT NULL,
  `mandal` varchar(30) NOT NULL,
  `district` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `no_temples` varchar(10) NOT NULL,
  `no_churches` varchar(10) NOT NULL,
  `no_mosques` varchar(10) NOT NULL,
  `leader_name` varchar(30) NOT NULL,
  `request_for` varchar(20) NOT NULL,
  `problem_details` varchar(40) NOT NULL,
  `requested` varchar(10) NOT NULL,
  `requested_by` varchar(30) NOT NULL,
  `request_details` varchar(40) NOT NULL,
  `request_phone` varchar(15) NOT NULL,
  `report_decision` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `report_reason` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `village_survey`
--

INSERT INTO `village_survey` (`id`, `time`, `date`, `refer`, `sub_refer`, `region`, `village_name`, `village_popu`, `panchayat_name`, `panchayat_popu`, `mandal`, `district`, `state`, `pincode`, `latitude`, `longitude`, `no_temples`, `no_churches`, `no_mosques`, `leader_name`, `request_for`, `problem_details`, `requested`, `requested_by`, `request_details`, `request_phone`, `report_decision`, `report_reason`, `status`) VALUES
(1, '12:12:11', '23/12/26', '3', '1', 'Agency', 'sdgj', '10000', '', '', '', '', '', '985632', '', '', '', '', '', '', 'Bore well', '', '', 'you', '', '9989898989', '', '', 0),
(2, '12:15:18', '23/12/26', '3', '1', 'Agency', 'mukk', '100', 'nnk', '1000', 'kiro', 'Anantapur', 'Andhra Pradesh', '546321', '2568', '3569', '20', '30', '40', 'son1', 'Community Problem', '', 'Village Su', 'youu', 'some change', '9989898989', 'Accept', 'ok ok', 2),
(3, '12:24:43', '23/12/26', '3', '1', 'Agency', 'mukk', '2000', 'kiol', '20000', 'kiro', 'Nellore', 'Andhra Pradesh', '555555', '1234', '5678', '10', '20', '30', 'son', 'Day Care Center', '', 'Letter', 'youy', 'some change', '9989895236', 'Reject', 'i think ok', -1);

-- --------------------------------------------------------

--
-- Table structure for table `widow_aged`
--

CREATE TABLE `widow_aged` (
  `id` int(100) NOT NULL,
  `app_type` int(10) NOT NULL,
  `time` varchar(10) NOT NULL,
  `date` varchar(10) NOT NULL,
  `refer` varchar(10) NOT NULL,
  `sub_refer` varchar(10) NOT NULL,
  `name` varchar(40) NOT NULL,
  `dob` varchar(10) NOT NULL,
  `adhar` varchar(20) NOT NULL,
  `husband_name` varchar(40) NOT NULL,
  `marrage_date` varchar(10) NOT NULL,
  `no_child` varchar(5) NOT NULL,
  `husband_passed` varchar(5) NOT NULL,
  `cause_death` varchar(40) NOT NULL,
  `pension` varchar(5) NOT NULL,
  `h_problem` varchar(40) NOT NULL,
  `living_status` varchar(30) NOT NULL,
  `village` varchar(30) NOT NULL,
  `street` varchar(30) NOT NULL,
  `mandal` varchar(30) NOT NULL,
  `district` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `requested` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `request_by` varchar(40) NOT NULL,
  `request_place` varchar(40) NOT NULL,
  `request_phone` varchar(15) NOT NULL,
  `status` int(10) NOT NULL,
  `photo` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `widow_aged`
--

INSERT INTO `widow_aged` (`id`, `app_type`, `time`, `date`, `refer`, `sub_refer`, `name`, `dob`, `adhar`, `husband_name`, `marrage_date`, `no_child`, `husband_passed`, `cause_death`, `pension`, `h_problem`, `living_status`, `village`, `street`, `mandal`, `district`, `state`, `pincode`, `phone`, `requested`, `request_by`, `request_place`, `request_phone`, `status`, `photo`) VALUES
(1, 0, '10:46:24', '23/12/26', '3', '1', 'some', '2023-12-26', '', 'ho', '', '', '5986', '', '', '', '', '', '', '', '', '', '555555', '9989898989', '', '', '', '', 0, '1.png'),
(2, 0, '10:47:20', '23/12/26', '3', '1', 'some', '2023-12-26', '693', 'hi', '2023-12-27', '60', '2000', 'cancer', 'yes', 'freaver', '', 'mlkop', 'mainsp', 'kirp', 'Kurnool', 'Andhra Pradesh', '253526', '998989896', 'Christiani', 'hip', 'kkd', '999999999', 1, '1.png'),
(3, 0, '10:48:35', '23/12/26', '3', '1', 'some', '2023-12-26', '569', 'evado', '2023-12-27', '20', '1999', 'cancer', 'yes', 'freaver', '', 'mlko', 'mains', 'kiro', 'Krishna', 'Andhra Pradesh', '253526', '998989896', 'Other', 'hi', 'kkd', '999999999', 2, '1.png'),
(4, 1, '11:04:03', '23/12/26', '3', '1', 'sarif', '1970-01-13', '2569', 'hohoo', '2023-12-27', '100', '2000', 'cancer', 'yes', 'freaver', '', 'mlkop', 'mainsp', 'kiro', 'Anantapur', 'Andhra Pradesh', '253526', '9989898989', 'Village Survy', 'hip', 'kkd', '999999999', 0, '1.png'),
(5, 1, '03:53:12', '23/12/27', '6', '1', 'some', '1971-02-02', '3000', 'hoho', '2023-12-27', '90', '2009', 'cancer', 'no', 'freaver', '', 'mlko', 'mainsp', 'kiro', 'Anantapur', 'Andhra Pradesh', '533533', '9999999999', 'Village Survy', 'hip', 'kkd', '999999999', 2, '5.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pregnant`
--
ALTER TABLE `pregnant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subadmin`
--
ALTER TABLE `subadmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `village_survey`
--
ALTER TABLE `village_survey`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widow_aged`
--
ALTER TABLE `widow_aged`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pregnant`
--
ALTER TABLE `pregnant`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subadmin`
--
ALTER TABLE `subadmin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `village_survey`
--
ALTER TABLE `village_survey`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `widow_aged`
--
ALTER TABLE `widow_aged`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
